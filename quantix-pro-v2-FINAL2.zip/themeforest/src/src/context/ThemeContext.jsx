import { createContext, useContext, useState, useCallback } from 'react';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => localStorage.getItem('qx-theme') || 'dark');
  const [dir, setDirState] = useState(() => localStorage.getItem('qx-dir') || 'ltr');

  const setTheme = useCallback((t) => {
    setThemeState(t);
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem('qx-theme', t);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  }, [theme, setTheme]);

  const toggleDir = useCallback(() => {
    const next = dir === 'ltr' ? 'rtl' : 'ltr';
    setDirState(next);
    document.documentElement.setAttribute('dir', next);
    localStorage.setItem('qx-dir', next);
  }, [dir]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, dir, toggleDir, isRTL: dir === 'rtl' }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
