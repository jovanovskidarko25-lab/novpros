import { createContext, useContext, useState, useCallback } from 'react';
import { DEMO_USER, delay } from '../utils/data.js';

// Credentials can be overridden via environment variables.
// Copy .env.example → .env and set VITE_DEMO_EMAIL / VITE_DEMO_PASSWORD,
// or configure them in Netlify → Site configuration → Environment variables.
const DEMO_EMAIL    = import.meta.env.VITE_DEMO_EMAIL    || DEMO_USER.email;
const DEMO_PASSWORD = import.meta.env.VITE_DEMO_PASSWORD || DEMO_USER.password;

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('qx-user');
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  });

  const login = useCallback(async (email, password) => {
    await delay(600);
    if (email === DEMO_EMAIL && password === DEMO_PASSWORD) {
      const u = { ...DEMO_USER };
      delete u.password;
      setUser(u);
      localStorage.setItem('qx-user', JSON.stringify(u));
      return { success: true };
    }
    return { success: false, error: 'Invalid email or password.' };
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('qx-user');
  }, []);

  const updateUser = useCallback((updates) => {
    setUser(prev => {
      const next = { ...prev, ...updates };
      localStorage.setItem('qx-user', JSON.stringify(next));
      return next;
    });
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, logout, updateUser, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
