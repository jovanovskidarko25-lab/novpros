import { createContext, useContext, useState, useCallback } from 'react';
import { randomId } from '../utils/data.js';

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const toast = useCallback((message, type = 'success', duration = 3000) => {
    const id = randomId();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), duration);
  }, []);

  const dismiss = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
  const colors = { success: 'var(--emerald)', error: 'var(--rose)', warning: 'var(--amber)', info: 'var(--accent)' };

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="qx-toast-container" aria-live="polite" aria-label="Notifications">
        {toasts.map(t => (
          <div key={t.id} className="qx-toast" role="alert" style={{ '--toast-color': colors[t.type] }}>
            <span className="toast-icon">{icons[t.type]}</span>
            <span className="toast-message">{t.message}</span>
            <button className="toast-dismiss" onClick={() => dismiss(t.id)} aria-label="Dismiss">✕</button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
