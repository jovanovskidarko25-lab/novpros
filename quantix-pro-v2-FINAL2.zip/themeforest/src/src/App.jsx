import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import { ThemeProvider } from './context/ThemeContext.jsx';
import { ToastProvider } from './context/ToastContext.jsx';
import AppLayout from './components/layout/AppLayout.jsx';

// ── Auth pages (non-lazy — small, needed immediately) ─────────────────────────
import {
  LoginPage, RegisterPage, ForgotPasswordPage,
  NotFoundPage, ServerErrorPage, ComingSoonPage, MaintenancePage,
} from './pages/Auth/index.jsx';

// ── Lazy-loaded page components ───────────────────────────────────────────────
const DashboardOverview  = lazy(() => import('./pages/Dashboard/index.jsx'));
const AnalyticsDashboard = lazy(() => import('./pages/Analytics/index.jsx'));
const CrmDashboard       = lazy(() => import('./pages/CRM/index.jsx'));
const FinancePage        = lazy(() => import('./pages/Finance/index.jsx'));
const AiDashboard        = lazy(() => import('./pages/AI/index.jsx'));
const ProjectsPage       = lazy(() => import('./pages/Projects/index.jsx'));
const KanbanPage         = lazy(() => import('./pages/Kanban/index.jsx'));
const CalendarPage       = lazy(() => import('./pages/Calendar/index.jsx'));
const ChatPage           = lazy(() => import('./pages/Chat/index.jsx'));
const EmailPage          = lazy(() => import('./pages/Email/index.jsx'));
const TablesPage         = lazy(() => import('./pages/Tables/index.jsx'));
const FormsPage          = lazy(() => import('./pages/Forms/index.jsx'));
const ProfilePage        = lazy(() => import('./pages/Profile/index.jsx'));
const SettingsPage       = lazy(() => import('./pages/Settings/index.jsx'));

// ── Loading fallback ──────────────────────────────────────────────────────────
function PageLoader() {
  return (
    <div className="app-loading">
      <div className="app-loading__spinner" />
      <span className="app-loading__text">Loading…</span>
    </div>
  );
}

// ── Protected route guard ─────────────────────────────────────────────────────
function Protected({ children }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
}

// ── Public route (redirect if already logged in) ──────────────────────────────
function PublicOnly({ children }) {
  const { isAuthenticated } = useAuth();
  if (isAuthenticated) return <Navigate to="/dashboard/analytics" replace />;
  return children;
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ToastProvider>
          <BrowserRouter>
            <Suspense fallback={<PageLoader />}>
              <Routes>
                {/* Root redirect */}
                <Route path="/" element={<Navigate to="/dashboard/analytics" replace />} />

                {/* Public auth routes */}
                <Route path="/login"           element={<PublicOnly><LoginPage /></PublicOnly>} />
                <Route path="/register"        element={<PublicOnly><RegisterPage /></PublicOnly>} />
                <Route path="/forgot-password" element={<PublicOnly><ForgotPasswordPage /></PublicOnly>} />

                {/* Utility pages */}
                <Route path="/coming-soon"  element={<ComingSoonPage />} />
                <Route path="/maintenance"  element={<MaintenancePage />} />
                <Route path="/500"          element={<ServerErrorPage />} />

                {/* Protected app routes */}
                <Route element={<Protected><AppLayout /></Protected>}>
                  {/* Dashboards */}
                  <Route path="/dashboard"           element={<DashboardOverview />} />
                  <Route path="/dashboard/analytics" element={<AnalyticsDashboard />} />
                  <Route path="/dashboard/crm"       element={<CrmDashboard />} />
                  <Route path="/dashboard/finance"   element={<FinancePage />} />
                  <Route path="/dashboard/ai"        element={<AiDashboard />} />

                  {/* Management */}
                  <Route path="/projects"  element={<ProjectsPage />} />
                  <Route path="/kanban"    element={<KanbanPage />} />
                  <Route path="/calendar"  element={<CalendarPage />} />

                  {/* Communication */}
                  <Route path="/chat"   element={<ChatPage />} />
                  <Route path="/email"  element={<EmailPage />} />

                  {/* Data */}
                  <Route path="/tables"  element={<TablesPage />} />
                  <Route path="/forms"   element={<FormsPage />} />

                  {/* Account */}
                  <Route path="/profile"   element={<ProfilePage />} />
                  <Route path="/settings"  element={<SettingsPage />} />
                </Route>

                {/* 404 — must be last */}
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </Suspense>
          </BrowserRouter>
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
