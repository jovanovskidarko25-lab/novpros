export default function StatCard({ label, value, change, trend, trendPositive, icon, color }) {
  const colorMap = {
    emerald: 'var(--emerald)',
    accent:  'var(--accent)',
    cyan:    'var(--sky)',
    amber:   'var(--amber)',
    violet:  'var(--violet)',
    rose:    'var(--rose)',
  };
  const accent = colorMap[color] || 'var(--accent)';

  return (
    <div className="qx-stat-card" style={{ '--card-accent': accent }}>
      <div className="stat-header">
        <span className="stat-label">{label}</span>
        <span className="stat-icon">{icon}</span>
      </div>
      <div className="stat-value">{value}</div>
      {change && (
        <div
          className={`stat-change ${trendPositive ? 'stat-change--positive' : 'stat-change--negative'}`}
          aria-label={`Change: ${change}`}
        >
          <span>{trend === 'up' ? '▲' : '▼'}</span>
          <span>{change}</span>
          <span className="stat-change__meta">vs last period</span>
        </div>
      )}
      <div className="stat-accent-bar" />
    </div>
  );
}
