import { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ open, onClose, title, subtitle, children, footer, maxWidth = 480 }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="qx-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="qx-modal" style={{ '--modal-max-width': `${maxWidth}px` }}>
        <div className="qx-modal__header">
          <div>
            <div className="qx-modal__title" id="modal-title">{title}</div>
            {subtitle && <div className="qx-modal__subtitle">{subtitle}</div>}
          </div>
          <button className="qx-modal__close-btn" onClick={onClose} aria-label="Close modal">
            <X size={16} />
          </button>
        </div>
        <div className="qx-modal__body">{children}</div>
        {footer && <div className="qx-modal__footer">{footer}</div>}
      </div>
    </div>
  );
}
