import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar.jsx';
import Header from './Header.jsx';
import { useLocalStorage, useMediaQuery } from '../../hooks/index.js';
import { useTheme } from '../../context/ThemeContext.jsx';

export default function AppLayout() {
  const isMobile = useMediaQuery('(max-width: 768px)');
  const [collapsed, setCollapsed] = useLocalStorage('qx-sidebar-collapsed', false);
  const { isRTL } = useTheme();

  const sidebarW = collapsed ? 64 : 240;
  const mainClass = [
    'qx-main',
    isMobile ? 'qx-main--mobile' : (isRTL ? 'qx-main--rtl' : 'qx-main--ltr'),
  ].join(' ');

  return (
    <>
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      <Header collapsed={collapsed} setCollapsed={setCollapsed} />

      {/* Mobile overlay */}
      {isMobile && !collapsed && (
        <div
          onClick={() => setCollapsed(true)}
          className="qx-overlay-mobile"
          aria-hidden="true"
        />
      )}

      <main
        id="main-content"
        className={mainClass}
        style={{ '--sidebar-w': `${sidebarW}px` }}
      >
        <Outlet />
      </main>
    </>
  );
}
