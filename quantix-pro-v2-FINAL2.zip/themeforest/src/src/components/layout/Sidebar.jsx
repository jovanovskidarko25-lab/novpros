import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { useTheme } from '../../context/ThemeContext.jsx';
import { useLocalStorage, useMediaQuery } from '../../hooks/index.js';
import {
  LayoutDashboard, BarChart3, Users, DollarSign, Brain,
  FolderKanban, Kanban, Calendar, MessageSquare, Mail,
  Table, FileText, User, Settings, LogOut, ChevronLeft,
  ChevronRight, Zap
} from 'lucide-react';

const NAV = [
  { section: 'Dashboards' },
  { path: '/dashboard',           label: 'Overview',   icon: LayoutDashboard },
  { path: '/dashboard/analytics', label: 'Analytics',  icon: BarChart3 },
  { path: '/dashboard/crm',       label: 'CRM',        icon: Users },
  { path: '/dashboard/finance',   label: 'Finance',    icon: DollarSign },
  { path: '/dashboard/ai',        label: 'AI / ML',    icon: Brain },
  { section: 'Management' },
  { path: '/projects',            label: 'Projects',   icon: FolderKanban },
  { path: '/kanban',              label: 'Kanban',     icon: Kanban },
  { path: '/calendar',            label: 'Calendar',   icon: Calendar },
  { section: 'Communication' },
  { path: '/chat',                label: 'Chat',       icon: MessageSquare },
  { path: '/email',               label: 'Email',      icon: Mail },
  { section: 'Data' },
  { path: '/tables',              label: 'Tables',     icon: Table },
  { path: '/forms',               label: 'Forms',      icon: FileText },
  { section: 'Account' },
  { path: '/profile',             label: 'Profile',    icon: User },
  { path: '/settings',            label: 'Settings',   icon: Settings },
];

export default function Sidebar({ collapsed, setCollapsed }) {
  const { user, logout } = useAuth();
  const { isRTL } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const isMobile = useMediaQuery('(max-width: 768px)');

  const w = collapsed ? 64 : 240;
  const isActive = (path) => location.pathname === path || (path !== '/dashboard' && location.pathname.startsWith(path + '/'));

  const sidebarClasses = [
    'qx-sidebar',
    isRTL ? 'qx-sidebar--rtl' : 'qx-sidebar--ltr',
    collapsed ? 'qx-sidebar--collapsed' : '',
    isMobile && collapsed ? 'qx-sidebar--hidden' : '',
  ].filter(Boolean).join(' ');

  return (
    <aside
      className={sidebarClasses}
      style={{ '--sidebar-w': `${w}px` }}
      aria-label="Main navigation"
    >
      {/* Logo */}
      <div className={`sidebar-logo${collapsed ? ' sidebar-logo--collapsed' : ''}`}>
        <div className="sidebar-logo__icon">
          <Zap size={16} color="white" strokeWidth={2.5} />
        </div>
        {!collapsed && <span className="sidebar-logo__name">Quantix Pro</span>}
      </div>

      {/* Nav */}
      <nav className="sidebar-nav">
        {NAV.map((item, i) => {
          if (item.section) {
            if (collapsed) return null;
            return (
              <div key={i} className="sidebar-section-label">{item.section}</div>
            );
          }
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <button
              key={item.path}
              onClick={() => { navigate(item.path); if (isMobile) setCollapsed(true); }}
              aria-label={item.label}
              aria-current={active ? 'page' : undefined}
              className={`sidebar-nav-btn${collapsed ? ' sidebar-nav-btn--collapsed' : ''}${active ? ' sidebar-nav-btn--active' : ''}`}
            >
              {active && !collapsed && <span className="sidebar-active-bar" />}
              <Icon size={16} strokeWidth={active ? 2.5 : 2} className="sidebar-nav-icon" />
              {!collapsed && (
                <span className={`sidebar-nav-label${active ? ' sidebar-nav-label--active' : ''}`}>
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User footer */}
      {!collapsed && user && (
        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="sidebar-user__avatar">{user.initials}</div>
            <div className="sidebar-user__info">
              <div className="sidebar-user__name">{user.name}</div>
              <div className="sidebar-user__plan">{user.plan} Plan</div>
            </div>
          </div>
          <button onClick={logout} className="qx-btn btn-secondary btn-sm sidebar-logout-btn">
            <LogOut size={13} /> Sign out
          </button>
        </div>
      )}

      {/* Collapse toggle */}
      {!isMobile && (
        <button
          onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className={`sidebar-toggle${isRTL ? ' sidebar-toggle--rtl' : ''}`}
        >
          {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
        </button>
      )}
    </aside>
  );
}
