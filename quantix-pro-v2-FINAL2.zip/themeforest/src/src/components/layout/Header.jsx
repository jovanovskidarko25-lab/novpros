import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { useTheme } from '../../context/ThemeContext.jsx';
import { useOutsideClick } from '../../hooks/index.js';
import { NOTIFICATIONS } from '../../utils/data.js';
import { Menu, Sun, Moon, Bell, Search } from 'lucide-react';

export default function Header({ collapsed, setCollapsed }) {
  const { user } = useAuth();
  const { theme, toggleTheme, toggleDir, isRTL } = useTheme();
  const navigate = useNavigate();
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQ, setSearchQ] = useState('');

  const notifRef = useOutsideClick(() => setNotifOpen(false));
  const unread = NOTIFICATIONS.filter(n => !n.read).length;

  const sidebarW = collapsed ? 64 : 240;
  const headerDir = isRTL ? 'qx-header--rtl' : 'qx-header--ltr';

  const quickLinks = ['Analytics', 'CRM', 'Finance', 'AI', 'Projects', 'Settings'];

  return (
    <header
      className={`qx-header ${headerDir}`}
      style={{ '--sidebar-w': `${sidebarW}px` }}
      role="banner"
    >
      {/* Left */}
      <div className="header-left">
        <button
          onClick={() => setCollapsed(!collapsed)}
          aria-label="Toggle sidebar"
          className="qx-btn btn-secondary btn-icon"
        >
          <Menu size={16} />
        </button>

        {/* Search */}
        <div className="header-search-wrap">
          {searchOpen ? (
            <input
              autoFocus
              className="qx-input header-search-input"
              placeholder="Search pages…"
              value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              onBlur={() => { setSearchOpen(false); setSearchQ(''); }}
              onKeyDown={e => {
                if (e.key === 'Escape') { setSearchOpen(false); setSearchQ(''); }
              }}
            />
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              aria-label="Open search"
              className="qx-btn btn-secondary btn-sm header-search-btn"
            >
              <Search size={14} />
              <span className="header-search-hint">Search…</span>
            </button>
          )}
          {searchOpen && searchQ && (
            <div className="header-search-dropdown">
              {quickLinks.filter(l => l.toLowerCase().includes(searchQ.toLowerCase())).map(l => (
                <button
                  key={l}
                  onMouseDown={() => {
                    navigate(`/${l.toLowerCase()}`);
                    setSearchOpen(false); setSearchQ('');
                  }}
                  className="header-search-result"
                >
                  {l}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right */}
      <div className="header-right">
        {/* RTL toggle */}
        <button onClick={toggleDir} aria-label="Toggle RTL" className="qx-btn btn-secondary btn-icon">
          <span className="header-rtl-label">{isRTL ? 'LTR' : 'RTL'}</span>
        </button>

        {/* Theme toggle */}
        <button onClick={toggleTheme} aria-label="Toggle theme" className="qx-btn btn-secondary btn-icon">
          {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="notif-wrap">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            aria-label={`Notifications (${unread} unread)`}
            aria-haspopup="true"
            aria-expanded={notifOpen}
            className="qx-btn btn-secondary btn-icon notif-trigger"
          >
            <Bell size={15} />
            {unread > 0 && <span className="notif-dot" />}
          </button>

          {notifOpen && (
            <div
              className={`notif-panel${isRTL ? ' notif-panel--rtl' : ''}`}
              role="dialog"
              aria-label="Notifications"
            >
              <div className="notif-panel__head">
                <span className="notif-panel__title">Notifications</span>
                {unread > 0 && <span className="notif-panel__badge">{unread} new</span>}
              </div>
              <div className="notif-panel__list">
                {NOTIFICATIONS.map(n => (
                  <div
                    key={n.id}
                    className={`notif-item ${n.read ? 'notif-item--read' : 'notif-item--unread'}`}
                  >
                    <span className="notif-item__icon">{n.icon}</span>
                    <div>
                      <div className="notif-item__title">{n.title}</div>
                      <div className="notif-item__message">{n.message}</div>
                      <div className="notif-item__time">{n.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Avatar */}
        <button
          onClick={() => navigate('/profile')}
          aria-label="Go to profile"
          className="header-avatar"
        >
          {user?.initials || 'AM'}
        </button>
      </div>
    </header>
  );
}
