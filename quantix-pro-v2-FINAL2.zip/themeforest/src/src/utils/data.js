// ── Shared mock data for all pages ──────────────────────────────────────────

export const DEMO_USER = {
  id: 'u1',
  name: 'Alex Morgan',
  email: 'admin@quantix.io',
  password: 'admin123',
  initials: 'AM',
  role: 'Administrator',
  plan: 'Pro',
  storageUsed: 67,
  avatar: null,
  company: 'Quantix Corp',
  bio: 'Full-stack developer and dashboard enthusiast.',
  phone: '+1 (555) 012-3456',
  location: 'San Francisco, CA',
  website: 'https://quantix.io',
  joined: '2023-01-15',
  twoFactorEnabled: false,
};

export const REVENUE_DATA = [
  { month: 'Jan', revenue: 48000, expenses: 31000, profit: 17000 },
  { month: 'Feb', revenue: 52000, expenses: 33000, profit: 19000 },
  { month: 'Mar', revenue: 61000, expenses: 35000, profit: 26000 },
  { month: 'Apr', revenue: 58000, expenses: 34000, profit: 24000 },
  { month: 'May', revenue: 74000, expenses: 38000, profit: 36000 },
  { month: 'Jun', revenue: 81000, expenses: 42000, profit: 39000 },
  { month: 'Jul', revenue: 93000, expenses: 46000, profit: 47000 },
  { month: 'Aug', revenue: 88000, expenses: 44000, profit: 44000 },
  { month: 'Sep', revenue: 102000, expenses: 48000, profit: 54000 },
  { month: 'Oct', revenue: 97000, expenses: 47000, profit: 50000 },
  { month: 'Nov', revenue: 115000, expenses: 52000, profit: 63000 },
  { month: 'Dec', revenue: 124000, expenses: 55000, profit: 69000 },
];

export const NOTIFICATIONS = [
  { id: 'n1', title: 'New Lead',          message: 'Sarah Chen from Vertex Corp added',       time: '2m ago',  read: false, type: 'success', icon: '👤' },
  { id: 'n2', title: 'Revenue Milestone', message: 'Monthly target 85% achieved',              time: '1h ago',  read: false, type: 'success', icon: '📈' },
  { id: 'n3', title: 'Project Update',    message: 'Mobile App Redesign moved to Review',      time: '3h ago',  read: false, type: 'info',    icon: '📋' },
  { id: 'n4', title: 'AI Model Alert',    message: 'ChurnPredictor latency spike detected',    time: '4h ago',  read: true,  type: 'warning', icon: '⚠️' },
  { id: 'n5', title: 'Security Alert',    message: 'New login from unrecognized device',       time: '6h ago',  read: true,  type: 'danger',  icon: '🔒' },
  { id: 'n6', title: 'Maintenance',       message: 'Scheduled maintenance Sun 2–4 AM UTC',     time: '1d ago',  read: true,  type: 'info',    icon: '🔧' },
];

export const ACTIVITY_FEED = [
  { action: 'New enterprise lead added',        user: 'Sarah Chen',  time: '2 min ago',  type: 'Lead',    color: '#10b981' },
  { action: 'Payment received from Cobalt Tech', user: 'System',     time: '18 min ago', type: 'Payment', color: '#6366f1' },
  { action: 'AI model ChurnPredictor deployed',  user: 'DevOps',     time: '1h ago',     type: 'Deploy',  color: '#8b5cf6' },
  { action: 'Support ticket #4821 closed',       user: 'Marcus R.',  time: '2h ago',     type: 'Support', color: '#06b6d4' },
  { action: 'New user registered (Pro plan)',    user: 'Priya Nair', time: '3h ago',     type: 'User',    color: '#f59e0b' },
  { action: 'Invoice INV-0849 sent',             user: 'Alex Morgan',time: '4h ago',     type: 'Invoice', color: '#6366f1' },
];

export const CRM_LEADS = [
  { id: 'l1', name: 'Sarah Chen',    company: 'Vertex Corp',    email: 'sarah@vertex.com',   value: 48000, status: 'qualified', stage: 'Proposal',    last: '2024-07-14' },
  { id: 'l2', name: 'James Liu',     company: 'Cobalt Tech',    email: 'james@cobalt.io',    value: 67000, status: 'hot',       stage: 'Negotiation', last: '2024-07-13' },
  { id: 'l3', name: 'Maya Patel',    company: 'Aurora Dynamics',email: 'maya@aurora.co',     value: 82000, status: 'warm',      stage: 'Demo',        last: '2024-07-12' },
  { id: 'l4', name: 'Carlos Ruiz',   company: 'Meridian Labs',  email: 'carlos@meridian.com',value: 23500, status: 'cold',      stage: 'Discovery',   last: '2024-07-11' },
  { id: 'l5', name: 'Aisha Okafor',  company: 'Solaris AI',     email: 'aisha@solaris.ai',   value: 31000, status: 'qualified', stage: 'Proposal',    last: '2024-07-10' },
  { id: 'l6', name: 'Tom Eriksson',  company: 'Nordic SaaS',    email: 'tom@nordic.se',      value: 55000, status: 'hot',       stage: 'Negotiation', last: '2024-07-09' },
];

export const FINANCE_TRANSACTIONS = [
  { id: 'tx1', description: 'Stripe Payment — Vertex Corp',  amount: 48000,  type: 'credit', category: 'Revenue',        date: '2024-07-15', status: 'completed' },
  { id: 'tx2', description: 'AWS Infrastructure',            amount: -8420,  type: 'debit',  category: 'Infrastructure', date: '2024-07-14', status: 'completed' },
  { id: 'tx3', description: 'Payroll — Engineering',         amount: -64000, type: 'debit',  category: 'Payroll',        date: '2024-07-13', status: 'completed' },
  { id: 'tx4', description: 'Stripe Payment — Cobalt Tech',  amount: 67000,  type: 'credit', category: 'Revenue',        date: '2024-07-12', status: 'completed' },
  { id: 'tx5', description: 'Google Workspace',              amount: -340,   type: 'debit',  category: 'Software',       date: '2024-07-11', status: 'completed' },
  { id: 'tx6', description: 'OpenAI API Credits',            amount: -1240,  type: 'debit',  category: 'AI / ML',        date: '2024-07-10', status: 'completed' },
  { id: 'tx7', description: 'Stripe Payment — Aurora Dyn.',  amount: 82000,  type: 'credit', category: 'Revenue',        date: '2024-07-09', status: 'pending'   },
];

export const AI_MODELS = [
  { name: 'ChurnPredictor v3',    accuracy: 94.2, precision: 92.8, recall: 95.1, f1: 93.9, status: 'deployed', lastUpdated: '2024-07-10' },
  { name: 'RevenueForecast v2',   accuracy: 91.5, precision: 90.2, recall: 92.8, f1: 91.5, status: 'deployed', lastUpdated: '2024-07-08' },
  { name: 'SentimentAnalyzer v1', accuracy: 88.7, precision: 87.4, recall: 89.9, f1: 88.6, status: 'staging',  lastUpdated: '2024-07-12' },
  { name: 'LeadScorer v4',        accuracy: 96.1, precision: 95.4, recall: 96.8, f1: 96.1, status: 'deployed', lastUpdated: '2024-07-05' },
  { name: 'AnomalyDetector v2',   accuracy: 89.3, precision: 88.1, recall: 90.5, f1: 89.3, status: 'training', lastUpdated: '2024-07-14' },
];

export const PROJECTS = [
  { id: 'p1', name: 'Mobile App Redesign',  status: 'review',       priority: 'high',     progress: 78, team: ['AM','SC','JL'], due: '2024-07-28', client: 'Vertex Corp'   },
  { id: 'p2', name: 'API Gateway v2',       status: 'in-progress',  priority: 'critical', progress: 45, team: ['AM','TR'],      due: '2024-08-10', client: 'Internal'      },
  { id: 'p3', name: 'Analytics Dashboard',  status: 'done',         priority: 'medium',   progress: 100, team: ['MP','CO'],     due: '2024-07-01', client: 'Cobalt Tech'   },
  { id: 'p4', name: 'CRM Integration',      status: 'planning',     priority: 'low',      progress: 12, team: ['JL','AO'],      due: '2024-09-01', client: 'Aurora Dyn.'   },
  { id: 'p5', name: 'ML Pipeline Upgrade',  status: 'in-progress',  priority: 'high',     progress: 62, team: ['AM','MP','TE'], due: '2024-08-22', client: 'Internal'      },
];

export const KANBAN_COLUMNS = [
  {
    id: 'todo', title: 'To Do', color: '#8b92a8',
    cards: [
      { id: 'k1', title: 'Design new onboarding flow',       priority: 'medium', assignee: 'SC', due: 'Jul 30' },
      { id: 'k2', title: 'Set up CI/CD for staging',         priority: 'low',    assignee: 'TR', due: 'Aug 5'  },
    ]
  },
  {
    id: 'in-progress', title: 'In Progress', color: '#6366f1',
    cards: [
      { id: 'k3', title: 'API rate limiting refactor',       priority: 'high',   assignee: 'AM', due: 'Jul 25' },
      { id: 'k4', title: 'Update billing integration',       priority: 'critical', assignee: 'JL', due: 'Jul 22' },
    ]
  },
  {
    id: 'review', title: 'Review', color: '#f59e0b',
    cards: [
      { id: 'k5', title: 'Mobile push notifications',        priority: 'medium', assignee: 'MP', due: 'Jul 20' },
    ]
  },
  {
    id: 'done', title: 'Done', color: '#10b981',
    cards: [
      { id: 'k6', title: 'Dark mode implementation',         priority: 'low',    assignee: 'AM', due: 'Jul 10' },
      { id: 'k7', title: 'Recharts upgrade to v2.12',        priority: 'low',    assignee: 'TR', due: 'Jul 8'  },
    ]
  },
];

export const CALENDAR_EVENTS = [
  { id: 'ev1', title: 'Board Meeting',       date: '2024-07-15', time: '10:00 AM', color: '#6366f1', type: 'meeting'  },
  { id: 'ev2', title: 'Sprint Review',       date: '2024-07-15', time: '2:00 PM',  color: '#10b981', type: 'meeting'  },
  { id: 'ev3', title: 'API Migration Due',   date: '2024-07-18', time: null,        color: '#f43f5e', type: 'deadline' },
  { id: 'ev4', title: 'Product Demo',        date: '2024-07-20', time: '3:00 PM',  color: '#8b5cf6', type: 'event'    },
  { id: 'ev5', title: 'Team Offsite',        date: '2024-07-22', time: '9:00 AM',  color: '#f59e0b', type: 'event'    },
  { id: 'ev6', title: 'Investor Call',       date: '2024-07-25', time: '11:00 AM', color: '#06b6d4', type: 'meeting'  },
];

export const CHAT_CONTACTS = [
  { id: 'c1', name: 'Sarah Chen',  initials: 'SC', color: '#10b981', status: 'online',  lastMsg: 'Can you review the proposal?',          time: '2m'  },
  { id: 'c2', name: 'James Liu',   initials: 'JL', color: '#6366f1', status: 'online',  lastMsg: 'The API docs look great.',               time: '18m' },
  { id: 'c3', name: 'Maya Patel',  initials: 'MP', color: '#8b5cf6', status: 'away',    lastMsg: 'Finished the dashboard mockups.',         time: '1h'  },
  { id: 'c4', name: 'Tom Eriksson',initials: 'TE', color: '#f59e0b', status: 'offline', lastMsg: 'Meeting notes sent.',                    time: '3h'  },
];

export const TABLE_ROWS = Array.from({ length: 20 }, (_, i) => ({
  id: `row-${i + 1}`,
  name: ['Alice Johnson','Bob Smith','Carol White','David Lee','Eva Martinez','Frank Chen','Grace Kim','Henry Wilson','Iris Brown','Jack Davis'][i % 10],
  email: `user${i + 1}@example.com`,
  role: ['Admin','Developer','Designer','Manager','Analyst'][i % 5],
  status: ['active','active','active','inactive','pending'][i % 5],
  joined: `2024-0${(i % 9) + 1}-${String((i % 28) + 1).padStart(2,'0')}`,
  revenue: Math.floor(Math.random() * 90000) + 10000,
}));

// ── Helper utilities ──────────────────────────────────────────────────────────

export function formatCurrency(n, compact = true) {
  if (compact) {
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
    return `$${n}`;
  }
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

export function formatNumber(n) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(0)}K`;
  return String(n);
}

export function randomId() {
  return Math.random().toString(36).slice(2, 10);
}

export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}

export function exportCSV(filename, headers, rows) {
  const content = [headers, ...rows].map(r => r.join(',')).join('\n');
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function avatarColor(str) {
  const colors = ['#6366f1','#8b5cf6','#06b6d4','#10b981','#f59e0b','#f43f5e','#ec4899'];
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

export function cx(...classes) {
  return classes.filter(Boolean).join(' ');
}
