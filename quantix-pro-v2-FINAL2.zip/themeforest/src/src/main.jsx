import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './styles/globals.css';

// Initialise theme before first paint (prevents flash)
const savedTheme = localStorage.getItem('qx-theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);

// Initialise RTL from saved preference
const savedDir = localStorage.getItem('qx-dir') || 'ltr';
document.documentElement.setAttribute('dir', savedDir);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
