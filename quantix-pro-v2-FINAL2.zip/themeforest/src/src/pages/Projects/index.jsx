import { useState } from 'react';
import Modal from '../../components/ui/Modal.jsx';
import StatCard from '../../components/ui/StatCard.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { PROJECTS, avatarColor } from '../../utils/data.js';
import { Plus } from 'lucide-react';

const STATUS_COLOR = { 'in-progress':'var(--accent)', review:'var(--amber)', done:'var(--emerald)', planning:'var(--sky)' };
const PRIORITY_COLOR = { critical:'var(--rose)', high:'var(--orange)', medium:'var(--amber)', low:'var(--sky)' };

export default function ProjectsPage() {
  const { toast } = useToast();
  const [projects, setProjects] = useState(PROJECTS);
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ name: '', client: '', status: 'planning', priority: 'medium', due: '' });

  const add = () => {
    if (!form.name) { toast('Project name required', 'error'); return; }
    setProjects(p => [...p, { id: `p${Date.now()}`, ...form, progress: 0, team: ['AM'] }]);
    setAddOpen(false); toast('Project created', 'success');
    setForm({ name: '', client: '', status: 'planning', priority: 'medium', due: '' });
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">Projects</h1><p className="page-subtitle">Track and manage all active projects</p></div>
        <button className="qx-btn btn-primary btn-sm" onClick={() => setAddOpen(true)}><Plus size={14} /> New Project</button>
      </div>

      <div className="stats-grid u-mb-20">
        <StatCard label="Total"       value={projects.length}                                              icon="📁" color="accent" />
        <StatCard label="In Progress" value={projects.filter(p=>p.status==='in-progress').length}          icon="⚡" color="violet" />
        <StatCard label="In Review"   value={projects.filter(p=>p.status==='review').length}               icon="👁️" color="amber" />
        <StatCard label="Completed"   value={projects.filter(p=>p.status==='done').length}                 icon="✅" color="emerald" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
        {projects.map(p => (
          <div key={p.id} className="qx-card" style={{ cursor: 'pointer', transition: 'transform 0.15s' }}>
            <div className="card-body">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 3 }}>{p.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{p.client}</div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 7px', borderRadius: 99, background: `${PRIORITY_COLOR[p.priority]}18`, color: PRIORITY_COLOR[p.priority] }}>{p.priority}</span>
                  <span style={{ fontSize: 11, fontWeight: 600, padding: '2px 7px', borderRadius: 99, background: `${STATUS_COLOR[p.status]}18`, color: STATUS_COLOR[p.status] }}>{p.status}</span>
                </div>
              </div>

              <div style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                  <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Progress</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)' }}>{p.progress}%</span>
                </div>
                <div className="qx-progress-track" style={{ height: 6 }}>
                  <div className="qx-progress-fill" style={{ width: `${p.progress}%`, background: STATUS_COLOR[p.status] }} />
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex' }}>
                  {p.team.map((t, i) => (
                    <div key={i} style={{ width: 24, height: 24, borderRadius: '50%', background: avatarColor(t), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700, color: 'white', border: '2px solid var(--bg-surface)', marginLeft: i > 0 ? -6 : 0 }}>{t}</div>
                  ))}
                </div>
                {p.due && <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>Due {p.due}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="New Project"
        footer={<><button className="qx-btn btn-secondary" onClick={() => setAddOpen(false)}>Cancel</button><button className="qx-btn btn-primary" onClick={add}>Create</button></>}
      >
        {[['name','Project Name'],['client','Client']].map(([k,l]) => (
          <div key={k} className="qx-field"><label className="qx-label">{l}</label>
            <input className="qx-input" value={form[k]} onChange={e => setForm(p => ({...p,[k]:e.target.value}))} /></div>
        ))}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {[['status','Status',['planning','in-progress','review','done']],['priority','Priority',['low','medium','high','critical']]].map(([k,l,opts]) => (
            <div key={k} className="qx-field"><label className="qx-label">{l}</label>
              <select className="qx-select" value={form[k]} onChange={e => setForm(p => ({...p,[k]:e.target.value}))}>
                {opts.map(o => <option key={o}>{o}</option>)}
              </select></div>
          ))}
        </div>
        <div className="qx-field"><label className="qx-label">Due Date</label>
          <input className="qx-input" type="date" value={form.due} onChange={e => setForm(p => ({...p,due:e.target.value}))} /></div>
      </Modal>
    </div>
  );
}
