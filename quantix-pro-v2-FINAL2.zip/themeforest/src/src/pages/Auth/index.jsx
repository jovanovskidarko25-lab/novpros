import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { isValidEmail } from '../../utils/data.js';
import { Mail, Lock, User, Building, ArrowLeft, Eye, EyeOff, Zap } from 'lucide-react';

// ── Shared Auth wrapper ───────────────────────────────────────────────────────
function AuthShell({ children }) {
  return (
    <div className="auth-shell">
      <div className="auth-shell__glow" />
      <div className="auth-shell__inner">
        <div className="auth-logo">
          <div className="auth-logo__icon">
            <Zap size={18} color="white" strokeWidth={2.5} />
          </div>
          <span className="auth-logo__name">Quantix Pro</span>
        </div>
        <div className="auth-card">{children}</div>
      </div>
    </div>
  );
}

// ── Reusable Field ────────────────────────────────────────────────────────────
function Field({ id, label, type = 'text', placeholder, value, onChange, onKeyDown, icon: Icon, error, autoComplete }) {
  const [showPw, setShowPw] = useState(false);
  const inputType = type === 'password' ? (showPw ? 'text' : 'password') : type;

  return (
    <div className="qx-field">
      <label htmlFor={id} className="qx-label">{label}</label>
      <div className="auth-field-wrap">
        {Icon && (
          <span className="auth-field-icon">
            <Icon size={14} />
          </span>
        )}
        <input
          id={id} name={id} type={inputType} placeholder={placeholder}
          value={value} autoComplete={autoComplete}
          onChange={e => onChange(e.target.value)} onKeyDown={onKeyDown}
          className={`qx-input${Icon ? ' auth-input-padded-l' : ''}${type === 'password' ? ' auth-input-padded-r' : ''}${error ? ' error' : ''}`}
        />
        {type === 'password' && (
          <button
            type="button" onClick={() => setShowPw(v => !v)} aria-label="Toggle password visibility"
            className="auth-pw-toggle"
          >
            {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
          </button>
        )}
      </div>
      {error && <p className="field-error" role="alert">{error}</p>}
    </div>
  );
}

function AlertBox({ msg, type = 'info' }) {
  return (
    <div role="alert" className={`auth-alert auth-alert--${type}`}>{msg}</div>
  );
}

function SubmitBtn({ loading, disabled, children, onClick }) {
  return (
    <button
      onClick={onClick} disabled={loading || disabled}
      className="qx-btn btn-primary auth-submit-btn"
    >
      {loading ? 'Please wait…' : children}
    </button>
  );
}

// ── Login Page ────────────────────────────────────────────────────────────────
export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) { setError('Please fill in all fields.'); return; }
    setLoading(true); setError('');
    const res = await login(email, password);
    setLoading(false);
    if (res.success) navigate('/dashboard/analytics');
    else setError(res.error ?? 'Login failed.');
  };
  const onKey = (e) => { if (e.key === 'Enter') handleLogin(); };

  return (
    <AuthShell>
      <h1 className="auth-title">Welcome back</h1>
      <p className="auth-subtitle">Sign in to your Quantix account</p>
      {error && <AlertBox msg={error} type="error" />}
      <Field id="login-email" label="Email address" type="email" placeholder="admin@quantix.io"
        value={email} onChange={setEmail} onKeyDown={onKey} icon={Mail} autoComplete="email" />
      <Field id="login-password" label="Password" type="password" placeholder="••••••••"
        value={password} onChange={setPassword} onKeyDown={onKey} icon={Lock} autoComplete="current-password" />
      <div className="auth-forgot-row">
        <button onClick={() => navigate('/forgot-password')} className="auth-link">
          Forgot password?
        </button>
      </div>
      <SubmitBtn onClick={handleLogin} loading={loading}>Sign in →</SubmitBtn>
      <AlertBox msg="Demo: admin@quantix.io / admin123" type="info" />
      <p className="auth-footer">
        Don't have an account?{' '}
        <button onClick={() => navigate('/register')} className="auth-link">Create one</button>
      </p>
    </AuthShell>
  );
}

// ── Register Page ─────────────────────────────────────────────────────────────
export function RegisterPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', company: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(false);

  const set = (k) => (v) => setForm(prev => ({ ...prev, [k]: v }));

  const validate = () => {
    const e = {};
    if (!form.name.trim())                           e.name = 'Full name is required';
    if (!form.email || !isValidEmail(form.email))    e.email = 'Valid email required';
    if (!form.password || form.password.length < 8)  e.password = 'Minimum 8 characters';
    if (form.password !== form.confirm)              e.confirm = "Passwords don't match";
    return e;
  };

  if (done) return (
    <AuthShell>
      <div className="auth-success-state">
        <div className="auth-success-emoji">🎉</div>
        <h2 className="auth-title">Account created!</h2>
        <p className="auth-subtitle">You're all set. Sign in to start using Quantix Pro.</p>
        <SubmitBtn onClick={() => navigate('/login')}>Go to Login →</SubmitBtn>
      </div>
    </AuthShell>
  );

  return (
    <AuthShell>
      <h1 className="auth-title">Create account</h1>
      <p className="auth-subtitle">Start your 14-day free trial. No credit card required.</p>
      <Field id="reg-name"     label="Full name"          placeholder="Alex Morgan"     value={form.name}     onChange={set('name')}     icon={User}     error={errors.name}     autoComplete="name" />
      <Field id="reg-email"    label="Email address"      type="email" placeholder="you@company.com" value={form.email} onChange={set('email')} icon={Mail} error={errors.email} autoComplete="email" />
      <Field id="reg-company"  label="Company (optional)" placeholder="Acme Corp"       value={form.company}  onChange={set('company')}  icon={Building} autoComplete="organization" />
      <Field id="reg-password" label="Password"           type="password" placeholder="Min 8 characters" value={form.password} onChange={set('password')} icon={Lock} error={errors.password} autoComplete="new-password" />
      <Field id="reg-confirm"  label="Confirm password"   type="password" placeholder="Repeat password"  value={form.confirm}  onChange={set('confirm')}  icon={Lock} error={errors.confirm}  autoComplete="new-password" />
      <SubmitBtn onClick={() => { const e = validate(); setErrors(e); if (!Object.keys(e).length) setDone(true); }}>
        Create Account →
      </SubmitBtn>
      <p className="auth-footer">
        Already have an account?{' '}
        <button onClick={() => navigate('/login')} className="auth-link">Sign in</button>
      </p>
    </AuthShell>
  );
}

// ── Forgot Password Page ──────────────────────────────────────────────────────
export function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  return (
    <AuthShell>
      <button onClick={() => navigate('/login')} className="auth-back-btn">
        <ArrowLeft size={14} /> Back to sign in
      </button>
      {sent ? (
        <div className="auth-sent-state">
          <div className="auth-sent-emoji">📬</div>
          <h2 className="auth-title">Check your inbox</h2>
          <p className="auth-subtitle">
            We sent a reset link to <strong className="auth-email-strong">{email}</strong>
          </p>
          <SubmitBtn onClick={() => { setSent(false); setEmail(''); }}>Try a different email</SubmitBtn>
        </div>
      ) : (
        <>
          <h1 className="auth-title">Reset password</h1>
          <p className="auth-subtitle">Enter your email and we'll send you a reset link.</p>
          {error && <AlertBox msg={error} type="error" />}
          <Field id="forgot-email" label="Email address" type="email" placeholder="admin@quantix.io"
            value={email} onChange={(v) => { setEmail(v); setError(''); }} icon={Mail} autoComplete="email" />
          <SubmitBtn onClick={() => { if (!email || !isValidEmail(email)) { setError('Please enter a valid email.'); return; } setSent(true); }}>
            Send Reset Link
          </SubmitBtn>
        </>
      )}
    </AuthShell>
  );
}

// ── 404 Not Found Page ────────────────────────────────────────────────────────
export function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="util-page util-page--indigo-glow">
      <div className="util-page__glow" />
      <div className="util-page__inner">
        <div className="util-page__code util-page__code--indigo">404</div>
        <h1 className="util-page__title">Page not found</h1>
        <p className="util-page__subtitle">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="util-page__actions">
          <button onClick={() => navigate('/dashboard/analytics')} className="qx-btn btn-primary">Go to Dashboard</button>
          <button onClick={() => window.history.back()} className="qx-btn btn-secondary">Go Back</button>
        </div>
      </div>
    </div>
  );
}

// ── 500 Server Error Page ─────────────────────────────────────────────────────
export function ServerErrorPage() {
  const navigate = useNavigate();
  return (
    <div className="util-page util-page--rose-glow">
      <div className="util-page__glow" />
      <div className="util-page__inner">
        <div className="util-page__code util-page__code--rose">500</div>
        <h1 className="util-page__title">Internal server error</h1>
        <p className="util-page__subtitle">
          Something went wrong on our end. We've been notified and are working on a fix.
        </p>
        <div className="util-page__actions">
          <button onClick={() => window.location.reload()} className="qx-btn btn-primary">Reload Page</button>
          <button onClick={() => navigate('/dashboard/analytics')} className="qx-btn btn-secondary">Go to Dashboard</button>
        </div>
      </div>
    </div>
  );
}

// ── Coming Soon Page ──────────────────────────────────────────────────────────
export function ComingSoonPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  return (
    <div className="util-page util-page--indigo-glow">
      <div className="util-page__glow" />
      <div className="util-page__inner util-page__inner--wide">
        <div className="util-page__icon">🚀</div>
        <h1 className="util-page__code util-page__code--indigo util-page__code--sm">Coming Soon</h1>
        <p className="util-page__subtitle">
          We're working on something amazing. Enter your email to be notified when we launch.
        </p>
        {subscribed ? (
          <div className="coming-soon-subscribed">
            ✅ You're on the list! We'll email you at <strong>{email}</strong>
          </div>
        ) : (
          <div className="coming-soon-form">
            <input
              className="qx-input" placeholder="your@email.com"
              value={email} onChange={e => setEmail(e.target.value)}
            />
            <button className="qx-btn btn-primary" onClick={() => { if (email && isValidEmail(email)) setSubscribed(true); }}>
              Notify me
            </button>
          </div>
        )}
        <button onClick={() => navigate('/dashboard/analytics')} className="util-page__back-link">
          ← Back to Dashboard
        </button>
      </div>
    </div>
  );
}

// ── Maintenance Page ──────────────────────────────────────────────────────────
export function MaintenancePage() {
  return (
    <div className="util-page util-page--amber-glow">
      <div className="util-page__glow" />
      <div className="util-page__inner">
        <div className="util-page__icon">🔧</div>
        <h1 className="util-page__title util-page__title--lg">Under Maintenance</h1>
        <p className="util-page__subtitle">
          We're performing scheduled maintenance. We'll be back shortly.
          <br />Estimated completion: <strong className="util-page__amber-text">Sunday 4:00 AM UTC</strong>
        </p>
        <div className="maintenance-window-card">
          <div className="maintenance-window-label">MAINTENANCE WINDOW</div>
          <div className="maintenance-window-time">Sunday, July 21 · 2:00 AM – 4:00 AM UTC</div>
        </div>
        <p className="util-page__follow-text">
          Follow{' '}
          <a href="#" className="auth-link">@quantixpro</a>
          {' '}for status updates.
        </p>
      </div>
    </div>
  );
}
