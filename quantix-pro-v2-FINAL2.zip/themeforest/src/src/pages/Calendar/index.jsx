import { useState } from 'react';
import Modal from '../../components/ui/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { CALENDAR_EVENTS, randomId } from '../../utils/data.js';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

export default function CalendarPage() {
  const { toast } = useToast();
  const [year, setYear] = useState(2024);
  const [month, setMonth] = useState(6);
  const [events, setEvents] = useState(CALENDAR_EVENTS);
  const [addOpen, setAddOpen] = useState(false);
  const [selDay, setSelDay] = useState(null);
  const [form, setForm] = useState({ title: '', time: '', color: '#6366f1', type: 'meeting' });

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const eventsForDay = (day) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return events.filter(e => e.date === dateStr);
  };

  const prev = () => { if (month === 0) { setMonth(11); setYear(y => y - 1); } else setMonth(m => m - 1); };
  const next = () => { if (month === 11) { setMonth(0); setYear(y => y + 1); } else setMonth(m => m + 1); };

  const addEvent = () => {
    if (!form.title || !selDay) { toast('Title required', 'error'); return; }
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(selDay).padStart(2, '0')}`;
    setEvents(prev => [...prev, { id: randomId(), ...form, date: dateStr }]);
    setAddOpen(false); toast('Event added', 'success');
    setForm({ title: '', time: '', color: '#6366f1', type: 'meeting' });
  };

  const cells = Array.from({ length: firstDay + daysInMonth }, (_, i) => (i < firstDay ? null : i - firstDay + 1));
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">Calendar</h1><p className="page-subtitle">Schedule and manage events</p></div>
        <button className="qx-btn btn-primary btn-sm" onClick={() => { setSelDay(new Date().getDate()); setAddOpen(true); }}>
          <Plus size={14} /> Add Event
        </button>
      </div>

      <div className="qx-card">
        <div className="card-header">
          <button className="qx-btn btn-secondary btn-icon" onClick={prev}><ChevronLeft size={15} /></button>
          <span style={{ fontWeight: 700, fontSize: 16 }}>{MONTHS[month]} {year}</span>
          <button className="qx-btn btn-secondary btn-icon" onClick={next}><ChevronRight size={15} /></button>
        </div>
        <div style={{ padding: '0 8px 8px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, marginBottom: 4 }}>
            {DAYS.map(d => <div key={d} style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: 'var(--text-tertiary)', padding: '8px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{d}</div>)}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
            {cells.map((day, i) => {
              const dayEvents = day ? eventsForDay(day) : [];
              const isToday = day === 15 && month === 6 && year === 2024;
              return (
                <div
                  key={i}
                  onClick={() => day && (setSelDay(day), setAddOpen(true))}
                  style={{
                    minHeight: 72, padding: '6px 8px', borderRadius: 'var(--radius-md)',
                    background: day ? 'var(--bg-elevated)' : 'transparent',
                    border: isToday ? '2px solid var(--accent)' : '1px solid transparent',
                    cursor: day ? 'pointer' : 'default',
                    transition: 'background 0.15s',
                  }}
                >
                  {day && (
                    <>
                      <div style={{ fontSize: 12, fontWeight: isToday ? 700 : 400, color: isToday ? 'var(--accent)' : 'var(--text-secondary)', marginBottom: 4 }}>{day}</div>
                      {dayEvents.slice(0, 2).map(e => (
                        <div key={e.id} style={{ fontSize: 10, fontWeight: 600, padding: '1px 5px', borderRadius: 3, background: `${e.color}22`, color: e.color, marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.title}</div>
                      ))}
                      {dayEvents.length > 2 && <div style={{ fontSize: 10, color: 'var(--text-tertiary)' }}>+{dayEvents.length - 2} more</div>}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <Modal open={addOpen} onClose={() => setAddOpen(false)} title={`Add Event — ${MONTHS[month]} ${selDay}`}
        footer={<><button className="qx-btn btn-secondary" onClick={() => setAddOpen(false)}>Cancel</button><button className="qx-btn btn-primary" onClick={addEvent}>Add Event</button></>}
      >
        <div className="qx-field"><label className="qx-label">Title</label><input className="qx-input" value={form.title} onChange={e => setForm(p=>({...p,title:e.target.value}))} placeholder="Event title" /></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="qx-field"><label className="qx-label">Time</label><input className="qx-input" type="time" value={form.time} onChange={e => setForm(p=>({...p,time:e.target.value}))} /></div>
          <div className="qx-field"><label className="qx-label">Type</label>
            <select className="qx-select" value={form.type} onChange={e => setForm(p=>({...p,type:e.target.value}))}>
              {['meeting','event','deadline','reminder'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div className="qx-field"><label className="qx-label">Color</label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {['#6366f1','#10b981','#f43f5e','#f59e0b','#8b5cf6','#06b6d4'].map(c => (
              <div key={c} onClick={() => setForm(p=>({...p,color:c}))} style={{ width: 28, height: 28, borderRadius: '50%', background: c, cursor: 'pointer', border: form.color === c ? '3px solid var(--text-primary)' : '3px solid transparent', transition: 'border 0.15s' }} />
            ))}
          </div>
        </div>
      </Modal>
    </div>
  );
}
