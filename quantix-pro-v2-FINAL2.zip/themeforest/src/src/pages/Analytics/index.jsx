import { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import StatCard from '../../components/ui/StatCard.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { REVENUE_DATA, ACTIVITY_FEED, exportCSV } from '../../utils/data.js';
import { RefreshCw, Download } from 'lucide-react';

const TT = { contentStyle: { background: 'var(--bg-surface)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 } };

const TRAFFIC = [
  { name: 'Organic', value: 42, color: 'var(--accent)' },
  { name: 'Direct',  value: 28, color: 'var(--emerald)' },
  { name: 'Referral',value: 18, color: 'var(--violet)' },
  { name: 'Social',  value: 12, color: 'var(--amber)' },
];

export default function AnalyticsDashboard() {
  const { toast } = useToast();
  const [range, setRange] = useState('30d');
  const [loading, setLoading] = useState(false);

  const slices = { '7d': REVENUE_DATA.slice(-2), '30d': REVENUE_DATA.slice(-5), '90d': REVENUE_DATA.slice(-8), '12m': REVENUE_DATA };

  const refresh = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); toast('Data refreshed', 'success'); }, 1200);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Analytics Dashboard</h1>
          <p className="page-subtitle">Business performance &amp; growth metrics</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="qx-btn btn-secondary btn-sm" onClick={refresh} disabled={loading}>
            <RefreshCw size={13} className={loading ? 'qx-spin' : ''} />
            {loading ? 'Refreshing…' : 'Refresh'}
          </button>
          <button className="qx-btn btn-secondary btn-sm" onClick={() => {
            exportCSV('revenue.csv', ['Month','Revenue','Expenses','Profit'], REVENUE_DATA.map(r => [r.month, r.revenue, r.expenses, r.profit]));
            toast('Exported!');
          }}>
            <Download size={13} /> Export
          </button>
        </div>
      </div>

      <div className="stats-grid u-mb-20">
        <StatCard label="Total Revenue"    value="$1.24M"  change="+22.4%" trend="up"   trendPositive icon="💰" color="emerald" />
        <StatCard label="Active Users"     value="42,891"  change="+11.7%" trend="up"   trendPositive icon="👥" color="accent" />
        <StatCard label="Conversion Rate"  value="3.7%"    change="+0.9%"  trend="up"   trendPositive icon="🎯" color="cyan" />
        <StatCard label="Bounce Rate"      value="38.2%"   change="-4.1%"  trend="down" trendPositive icon="↩️" color="amber" />
      </div>

      {/* Revenue chart */}
      <div className="qx-card" style={{ marginBottom: 20 }}>
        <div className="card-header">
          <div>
            <div className="card-title">Revenue Overview</div>
            <div className="card-subtitle">Revenue vs. expenses over time</div>
          </div>
          <div style={{ display: 'flex', gap: 4, background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)', borderRadius: 8, padding: 3 }}>
            {['7d','30d','90d','12m'].map(r => (
              <button key={r} onClick={() => setRange(r)} style={{
                padding: '5px 10px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600,
                cursor: 'pointer', fontFamily: 'var(--font-sans)',
                background: range === r ? 'var(--bg-surface)' : 'transparent',
                color: range === r ? 'var(--text-primary)' : 'var(--text-tertiary)', transition: 'all 0.15s',
              }}>{r}</button>
            ))}
          </div>
        </div>
        <div className="card-body">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={slices[range]}>
              <defs>
                <linearGradient id="gRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="var(--emerald)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--emerald)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gExp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="var(--rose)" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="var(--rose)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} tickFormatter={v => `$${v/1000}k`} />
              <Tooltip {...TT} formatter={v => [`$${v.toLocaleString()}`, '']} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="revenue"  name="Revenue"  stroke="var(--emerald)" fill="url(#gRev)" strokeWidth={2} />
              <Area type="monotone" dataKey="expenses" name="Expenses" stroke="var(--rose)"    fill="url(#gExp)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom row */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Bar chart */}
        <div className="qx-card">
          <div className="card-header">
            <div><div className="card-title">Monthly Profit</div><div className="card-subtitle">Net profit by month</div></div>
          </div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={REVENUE_DATA.slice(-6)}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} />
                <YAxis tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} tickFormatter={v => `$${v/1000}k`} />
                <Tooltip {...TT} formatter={v => [`$${v.toLocaleString()}`, 'Profit']} />
                <Bar dataKey="profit" fill="var(--accent)" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie chart */}
        <div className="qx-card">
          <div className="card-header">
            <div><div className="card-title">Traffic Sources</div></div>
          </div>
          <div className="card-body" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={TRAFFIC} cx="50%" cy="50%" outerRadius={60} dataKey="value">
                  {TRAFFIC.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip {...TT} formatter={v => [`${v}%`, '']} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 12px', justifyContent: 'center', marginTop: 8 }}>
              {TRAFFIC.map(t => (
                <div key={t.name} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12 }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: t.color }} />
                  <span style={{ color: 'var(--text-secondary)' }}>{t.name}</span>
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{t.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Activity feed */}
      <div className="qx-card">
        <div className="card-header">
          <div><div className="card-title">Recent Activity</div><div className="card-subtitle">Latest platform events</div></div>
        </div>
        <div>
          {ACTIVITY_FEED.map((a, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 20px', borderBottom: i < ACTIVITY_FEED.length - 1 ? '1px solid var(--border-subtle)' : 'none' }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: a.color, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 500 }}>{a.action}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 1 }}>by {a.user}</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 11, background: 'var(--bg-elevated)', color: 'var(--text-secondary)', padding: '2px 7px', borderRadius: 4, border: '1px solid var(--border-subtle)' }}>{a.type}</span>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>{a.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
