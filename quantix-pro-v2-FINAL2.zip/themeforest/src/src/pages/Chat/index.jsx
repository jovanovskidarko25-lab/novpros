import { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { CHAT_CONTACTS, avatarColor, randomId } from '../../utils/data.js';
import { Send, Smile } from 'lucide-react';

const INITIAL_MESSAGES = {
  c1: [{ id: 'i1', from: 'other', text: 'Can you review the proposal doc I sent earlier?', time: '10:32 AM' }],
  c2: [{ id: 'i2', from: 'other', text: 'The API docs look great. Ready for review!', time: '10:14 AM' }],
  c3: [{ id: 'i3', from: 'other', text: 'Finished the dashboard mockups. Let me know what you think.', time: '9:45 AM' }],
  c4: [{ id: 'i4', from: 'other', text: 'Meeting notes sent to the team.', time: 'Yesterday' }],
};

const STATUS_COLOR = { online: 'var(--emerald)', away: 'var(--amber)', offline: 'var(--text-muted)' };

export default function ChatPage() {
  const { user } = useAuth();
  const [activeId, setActiveId] = useState('c1');
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);
  const active = CHAT_CONTACTS.find(c => c.id === activeId);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, activeId]);

  const send = () => {
    if (!input.trim()) return;
    const msg = { id: randomId(), from: 'me', text: input.trim(), time: 'Now' };
    setMessages(prev => ({ ...prev, [activeId]: [...(prev[activeId] || []), msg] }));
    setInput('');
    setTimeout(() => {
      setMessages(prev => ({ ...prev, [activeId]: [...(prev[activeId] || []), { id: randomId(), from: 'other', text: 'Got it! I\'ll take a look shortly.', time: 'Now' }] }));
    }, 1200);
  };

  return (
    <div className="page-container">
      <div className="page-header"><div><h1 className="page-title">Chat</h1><p className="page-subtitle">Team messaging</p></div></div>
      <div className="qx-card" style={{ display: 'flex', overflow: 'hidden', height: 520 }}>
        {/* Sidebar */}
        <div style={{ width: 240, borderRight: '1px solid var(--border-subtle)', flexShrink: 0, overflowY: 'auto' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-subtle)', fontSize: 12, fontWeight: 700, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Messages</div>
          {CHAT_CONTACTS.map(c => (
            <div key={c.id} onClick={() => setActiveId(c.id)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 16px', cursor: 'pointer', background: activeId === c.id ? 'var(--accent-bg)' : 'transparent', borderLeft: activeId === c.id ? '3px solid var(--accent)' : '3px solid transparent', transition: 'all 0.15s' }}>
              <div style={{ position: 'relative', flexShrink: 0 }}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: c.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: 'white' }}>{c.initials}</div>
                <div style={{ position: 'absolute', bottom: 0, right: 0, width: 9, height: 9, borderRadius: '50%', background: STATUS_COLOR[c.status], border: '2px solid var(--bg-surface)' }} />
              </div>
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 1 }}>{c.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-tertiary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.lastMsg}</div>
              </div>
              <div style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--text-muted)', flexShrink: 0 }}>{c.time}</div>
            </div>
          ))}
        </div>

        {/* Chat window */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: active.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'white' }}>{active.initials}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>{active.name}</div>
              <div style={{ fontSize: 11, color: STATUS_COLOR[active.status] }}>● {active.status}</div>
            </div>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
            {(messages[activeId] || []).map(msg => (
              <div key={msg.id} style={{ display: 'flex', justifyContent: msg.from === 'me' ? 'flex-end' : 'flex-start' }}>
                <div style={{ maxWidth: '70%', padding: '9px 13px', borderRadius: msg.from === 'me' ? '16px 16px 4px 16px' : '16px 16px 16px 4px', background: msg.from === 'me' ? 'var(--accent)' : 'var(--bg-elevated)', color: msg.from === 'me' ? 'white' : 'var(--text-primary)', fontSize: 13, lineHeight: 1.5 }}>
                  {msg.text}
                  <div style={{ fontSize: 10, opacity: 0.7, marginTop: 3, textAlign: 'right' }}>{msg.time}</div>
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border-subtle)', display: 'flex', gap: 8 }}>
            <input className="qx-input" placeholder="Type a message…" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} style={{ flex: 1 }} />
            <button className="qx-btn btn-primary btn-icon" onClick={send}><Send size={15} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
