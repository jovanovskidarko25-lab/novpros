import StatCard from '../../components/ui/StatCard.jsx';
import { ACTIVITY_FEED } from '../../utils/data.js';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

const revenueData = [
  { month: 'Jan', revenue: 42000 },
  { month: 'Feb', revenue: 47500 },
  { month: 'Mar', revenue: 45000 },
  { month: 'Apr', revenue: 53000 },
  { month: 'May', revenue: 58000 },
  { month: 'Jun', revenue: 55500 },
  { month: 'Jul', revenue: 63000 },
  { month: 'Aug', revenue: 69000 },
  { month: 'Sep', revenue: 72000 },
  { month: 'Oct', revenue: 68000 },
  { month: 'Nov', revenue: 78000 },
  { month: 'Dec', revenue: 84500 },
];

const stats = [
  { label: 'Total Revenue',    value: '$84,523',  change: '+12.4%', trend: 'up',   trendPositive: true,  icon: '💰', color: 'emerald' },
  { label: 'Active Users',     value: '24,891',   change: '+8.1%',  trend: 'up',   trendPositive: true,  icon: '👥', color: 'accent'  },
  { label: 'Conversion Rate',  value: '3.64%',    change: '-0.3%',  trend: 'down', trendPositive: false, icon: '📈', color: 'amber'   },
  { label: 'Avg. Session',     value: '4m 38s',   change: '+22s',   trend: 'up',   trendPositive: true,  icon: '⏱️', color: 'violet'  },
];

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tooltip">
      <div className="chart-tooltip__label">{label}</div>
      <div className="chart-tooltip__value">${payload[0].value.toLocaleString()}</div>
    </div>
  );
}

export default function DashboardOverview() {
  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Welcome back — here's what's happening today.</p>
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="stats-grid u-mb-20">
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      {/* Revenue Chart + Team Widget */}
      <div className="dashboard-main-grid">
        {/* Revenue Line Chart */}
        <div className="qx-card">
          <div className="card-header">
            <div>
              <div className="card-title">Revenue Overview</div>
              <div className="card-subtitle">Monthly revenue for the current year</div>
            </div>
          </div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={revenueData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="revenue" stroke="var(--accent)" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: 'var(--accent)' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Team Widget */}
        <div className="qx-card">
          <div className="card-header">
            <div className="card-title">Team Members</div>
          </div>
          <div className="team-list">
            {defaultTeam.map(m => (
              <div key={m.name} className="team-row">
                <div className="qx-avatar team-avatar">{m.initials}</div>
                <div className="team-info">
                  <div className="team-name">{m.name}</div>
                  <div className="team-role">{m.role}</div>
                </div>
                <span className={`qx-badge team-badge badge-${m.statusColor || 'green'}`}>
                  <span className="badge-dot" />
                  {m.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity Feed */}
      <div className="qx-card dashboard-activity">
        <div className="card-header">
          <div className="card-title">Recent Activity</div>
        </div>
        <div className="activity-list">
          {(ACTIVITY_FEED || defaultActivity).map((item, i) => (
            <div key={i} className="activity-row">
              <span className="activity-icon">{item.icon}</span>
              <div className="activity-content">
                <span className="activity-text">{item.text}</span>
                <span className="activity-time">{item.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const defaultTeam = [
  { name: 'Alex Morgan',    role: 'Product Lead',   initials: 'AM', status: 'Online',  statusColor: 'green' },
  { name: 'Sam Rivera',     role: 'Lead Engineer',  initials: 'SR', status: 'Online',  statusColor: 'green' },
  { name: 'Jordan Lee',     role: 'UX Designer',    initials: 'JL', status: 'Away',    statusColor: 'amber' },
  { name: 'Casey Kim',      role: 'Data Analyst',   initials: 'CK', status: 'Offline', statusColor: 'gray'  },
  { name: 'Taylor Brooks',  role: 'DevOps',         initials: 'TB', status: 'Online',  statusColor: 'green' },
];

const defaultActivity = [
  { icon: '🚀', text: 'New deployment pushed to production', time: '2 min ago' },
  { icon: '💳', text: 'Payment of $2,400 received from Acme Corp', time: '18 min ago' },
  { icon: '👤', text: 'New user registered: sarah.jones@email.com', time: '1 hr ago' },
  { icon: '🐛', text: 'Bug #4821 marked as resolved', time: '3 hrs ago' },
  { icon: '📊', text: 'Monthly report generated and sent', time: '5 hrs ago' },
  { icon: '🔔', text: 'Server CPU alert cleared automatically', time: '7 hrs ago' },
];
