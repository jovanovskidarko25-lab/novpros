import { useState } from 'react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import StatCard from '../../components/ui/StatCard.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { AI_MODELS } from '../../utils/data.js';
import { Brain, Play, Square, RefreshCw } from 'lucide-react';

const TT = { contentStyle: { background: 'var(--bg-surface)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 } };
const STATUS_COLOR = { deployed: 'var(--emerald)', staging: 'var(--amber)', training: 'var(--accent)' };

const RADAR_DATA = [
  { metric: 'Accuracy',  ChurnPredictor: 94, LeadScorer: 96 },
  { metric: 'Precision', ChurnPredictor: 93, LeadScorer: 95 },
  { metric: 'Recall',    ChurnPredictor: 95, LeadScorer: 97 },
  { metric: 'F1 Score',  ChurnPredictor: 94, LeadScorer: 96 },
  { metric: 'Speed',     ChurnPredictor: 88, LeadScorer: 91 },
];

export default function AiDashboard() {
  const { toast } = useToast();
  const [models, setModels] = useState(AI_MODELS);
  const [retraining, setRetraining] = useState(null);

  const retrain = (name) => {
    setRetraining(name);
    setTimeout(() => { setRetraining(null); toast(`${name} retraining complete`, 'success'); }, 2000);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">AI / ML Dashboard</h1><p className="page-subtitle">Model performance & deployment status</p></div>
        <button className="qx-btn btn-primary btn-sm" onClick={() => toast('New model training started', 'info')}>
          <Brain size={14} /> Train New Model
        </button>
      </div>

      <div className="stats-grid u-mb-20">
        <StatCard label="Deployed Models"  value={models.filter(m=>m.status==='deployed').length} icon="🤖" color="accent" />
        <StatCard label="Avg Accuracy"     value="91.8%"  change="+2.1%" trend="up" trendPositive icon="🎯" color="emerald" />
        <StatCard label="Daily Predictions" value="284K"  change="+14%" trend="up" trendPositive icon="⚡" color="violet" />
        <StatCard label="Models in Training" value={models.filter(m=>m.status==='training').length} icon="🔄" color="amber" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        <div className="qx-card">
          <div className="card-header"><div className="card-title">Model Comparison (Radar)</div></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={RADAR_DATA}>
                <PolarGrid stroke="var(--border-subtle)" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fill: 'var(--text-secondary)' }} />
                <Radar name="ChurnPredictor" dataKey="ChurnPredictor" stroke="var(--accent)"  fill="var(--accent)"  fillOpacity={0.2} />
                <Radar name="LeadScorer"     dataKey="LeadScorer"     stroke="var(--emerald)" fill="var(--emerald)" fillOpacity={0.2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="qx-card">
          <div className="card-header"><div className="card-title">Accuracy by Model</div></div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={models.map(m => ({ name: m.name.replace(' v','v').split(' ')[0], acc: m.accuracy }))} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" horizontal={false} />
                <XAxis type="number" domain={[80, 100]} tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: 'var(--text-tertiary)' }} width={90} />
                <Tooltip {...TT} formatter={v => [`${v}%`, 'Accuracy']} />
                <Bar dataKey="acc" fill="var(--accent)" radius={[0,4,4,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="qx-card">
        <div className="card-header"><div className="card-title">Model Registry</div></div>
        <div className="u-overflow-x-auto">
          <table className="qx-table">
            <thead><tr><th>Model</th><th>Status</th><th>Accuracy</th><th>F1 Score</th><th>Last Updated</th><th>Actions</th></tr></thead>
            <tbody>
              {models.map(m => (
                <tr key={m.name}>
                  <td style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{m.name}</td>
                  <td><span style={{ fontSize: 11, fontWeight: 600, color: STATUS_COLOR[m.status] }}>● {m.status}</span></td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{m.accuracy}%</td>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>{m.f1}%</td>
                  <td style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{m.lastUpdated}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="qx-btn btn-secondary btn-sm" onClick={() => retrain(m.name)} disabled={retraining === m.name}>
                        <RefreshCw size={12} className={retraining === m.name ? 'qx-spin' : ''} />
                        {retraining === m.name ? 'Training…' : 'Retrain'}
                      </button>
                      {m.status === 'deployed'
                        ? <button className="qx-btn btn-danger btn-sm" onClick={() => toast(`${m.name} stopped`,'warning')}><Square size={12} /></button>
                        : <button className="qx-btn btn-secondary btn-sm" onClick={() => toast(`${m.name} deployed`,'success')}><Play size={12} /></button>
                      }
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
