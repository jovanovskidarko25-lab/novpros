import { useState } from 'react';
import { Star, Trash2, Reply, Archive, RefreshCw, Inbox } from 'lucide-react';

const EMAILS = [
  { id: 'e1', from: 'Sarah Chen', subject: 'Proposal Review — Q3 Campaign', preview: 'Hi Alex, I have attached the updated proposal for Q3. Could you review by Friday?', time: '10:32 AM', read: false, starred: true },
  { id: 'e2', from: 'Stripe', subject: 'Payment received: $48,000.00', preview: 'A payment of $48,000.00 was received from Vertex Corp on your Stripe account.', time: '9:14 AM', read: false, starred: false },
  { id: 'e3', from: 'James Liu', subject: 'API Documentation v2 ready', preview: 'The updated API docs are live at docs.quantix.io. All endpoints are covered.', time: 'Yesterday', read: true, starred: false },
  { id: 'e4', from: 'GitHub', subject: 'Security alert: dependency vulnerability', preview: 'We found a vulnerability in lodash 4.17.15 used in quantix-pro/dashboard.', time: 'Yesterday', read: true, starred: true },
  { id: 'e5', from: 'Maya Patel', subject: 'Dashboard mockups ready for review', preview: 'Hey team — I have uploaded the new mockups to Figma. Link in the shared folder.', time: 'Mon', read: true, starred: false },
  { id: 'e6', from: 'Netlify', subject: 'Deploy preview ready', preview: 'Your deploy preview for branch feature/rtl-support is ready to review.', time: 'Mon', read: true, starred: false },
];

export default function EmailPage() {
  const [emails, setEmails] = useState(EMAILS);
  const [activeId, setActiveId] = useState('e1');
  const active = emails.find(e => e.id === activeId);

  const toggle = (id, key) => setEmails(prev => prev.map(e => e.id === id ? { ...e, [key]: !e[key] } : e));
  const del = (id) => { setEmails(prev => prev.filter(e => e.id !== id)); if (activeId === id) setActiveId(emails[0]?.id); };
  const markRead = (id) => setEmails(prev => prev.map(e => e.id === id ? { ...e, read: true } : e));

  return (
    <div className="page-container">
      <div className="page-header"><div><h1 className="page-title">Email</h1><p className="page-subtitle">Inbox — {emails.filter(e=>!e.read).length} unread</p></div>
        <button className="qx-btn btn-secondary btn-sm"><RefreshCw size={13} /> Refresh</button>
      </div>
      <div className="qx-card" style={{ display: 'flex', overflow: 'hidden', height: 540 }}>
        {/* Email list */}
        <div style={{ width: 300, borderRight: '1px solid var(--border-subtle)', overflowY: 'auto', flexShrink: 0 }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Inbox size={13} style={{ color: 'var(--text-tertiary)' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Inbox</span>
          </div>
          {emails.map(e => (
            <div key={e.id} onClick={() => { setActiveId(e.id); markRead(e.id); }}
              style={{ padding: '12px 14px', cursor: 'pointer', borderBottom: '1px solid var(--border-subtle)', background: activeId === e.id ? 'var(--accent-bg)' : 'transparent', borderLeft: activeId === e.id ? '3px solid var(--accent)' : '3px solid transparent', transition: 'all 0.15s' }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                <span style={{ fontSize: 13, fontWeight: e.read ? 400 : 700, color: 'var(--text-primary)' }}>{e.from}</span>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{e.time}</span>
              </div>
              <div style={{ fontSize: 12, fontWeight: e.read ? 400 : 600, color: e.read ? 'var(--text-secondary)' : 'var(--text-primary)', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.subject}</div>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{e.preview}</div>
              {!e.read && <div style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', marginTop: 6 }} />}
            </div>
          ))}
        </div>

        {/* Email body */}
        {active && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ padding: '12px 20px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', gap: 6 }}>
              <button className="qx-btn btn-secondary btn-sm"><Reply size={13} /> Reply</button>
              <button className="qx-btn btn-secondary btn-sm"><Archive size={13} /> Archive</button>
              <button className="qx-btn btn-secondary btn-sm" onClick={() => toggle(active.id, 'starred')}>
                <Star size={13} style={{ fill: active.starred ? 'var(--amber)' : 'none', color: active.starred ? 'var(--amber)' : 'currentColor' }} />
              </button>
              <button className="qx-btn btn-danger btn-sm" onClick={() => del(active.id)}><Trash2 size={13} /></button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 12 }}>{active.subject}</h2>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>From: {active.from}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>To: admin@quantix.io</div>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{active.time}</div>
              </div>
              <div style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.8 }}>
                <p style={{ marginBottom: 16 }}>{active.preview}</p>
                <p style={{ marginBottom: 16 }}>Please let me know if you have any questions or need any changes before we proceed with the next steps.</p>
                <p>Best regards,<br /><strong style={{ color: 'var(--text-primary)' }}>{active.from}</strong></p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
