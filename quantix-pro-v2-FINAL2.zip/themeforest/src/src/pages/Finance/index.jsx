import { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import StatCard from '../../components/ui/StatCard.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { FINANCE_TRANSACTIONS, REVENUE_DATA, exportCSV } from '../../utils/data.js';
import { Download, TrendingUp, TrendingDown } from 'lucide-react';

const TT = { contentStyle: { background: 'var(--bg-surface)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 } };

export default function FinancePage() {
  const { toast } = useToast();
  const [filter, setFilter] = useState('all');
  const filtered = FINANCE_TRANSACTIONS.filter(t => filter === 'all' || t.type === filter);

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">Finance</h1><p className="page-subtitle">Revenue, expenses & transaction history</p></div>
        <button className="qx-btn btn-secondary btn-sm" onClick={() => { exportCSV('transactions.csv',['Date','Description','Amount','Type','Category','Status'],FINANCE_TRANSACTIONS.map(t=>[t.date,t.description,t.amount,t.type,t.category,t.status])); toast('Exported!'); }}>
          <Download size={13} /> Export
        </button>
      </div>

      <div className="stats-grid u-mb-20">
        <StatCard label="Total Revenue"   value="$197K"  change="+22%" trend="up"   trendPositive icon="💰" color="emerald" />
        <StatCard label="Total Expenses"  value="$73.7K" change="+8%"  trend="up"   trendPositive={false} icon="💸" color="rose" />
        <StatCard label="Net Profit"      value="$123K"  change="+31%" trend="up"   trendPositive icon="📈" color="accent" />
        <StatCard label="Burn Rate"       value="$9.8K"  change="-2%"  trend="down" trendPositive icon="🔥" color="amber" />
      </div>

      <div className="qx-card" style={{ marginBottom: 20 }}>
        <div className="card-header"><div><div className="card-title">Cash Flow</div><div className="card-subtitle">12-month overview</div></div></div>
        <div className="card-body">
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={REVENUE_DATA}>
              <defs>
                <linearGradient id="gP" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="var(--accent)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="var(--accent)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} tickFormatter={v => `$${v/1000}k`} />
              <Tooltip {...TT} formatter={v => [`$${v.toLocaleString()}`, '']} />
              <Area type="monotone" dataKey="profit" name="Profit" stroke="var(--accent)" fill="url(#gP)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="qx-card">
        <div className="card-header">
          <div className="card-title">Transactions</div>
          <div style={{ display: 'flex', gap: 4, background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)', borderRadius: 8, padding: 3 }}>
            {['all','credit','debit'].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{ padding: '4px 10px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)', background: filter === f ? 'var(--bg-surface)' : 'transparent', color: filter === f ? 'var(--text-primary)' : 'var(--text-tertiary)', textTransform: 'capitalize', transition: 'all 0.15s' }}>{f}</button>
            ))}
          </div>
        </div>
        <div className="u-overflow-x-auto">
          <table className="qx-table">
            <thead><tr><th>Date</th><th>Description</th><th>Category</th><th style={{ textAlign: 'right' }}>Amount</th><th>Status</th></tr></thead>
            <tbody>
              {filtered.map(t => (
                <tr key={t.id}>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{t.date}</td>
                  <td style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{t.description}</td>
                  <td><span style={{ fontSize: 11, background: 'var(--bg-elevated)', padding: '2px 7px', borderRadius: 4, border: '1px solid var(--border-subtle)' }}>{t.category}</span></td>
                  <td style={{ textAlign: 'right', fontWeight: 700, fontFamily: 'var(--font-mono)', color: t.type === 'credit' ? 'var(--emerald)' : 'var(--rose)' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                      {t.type === 'credit' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                      {t.type === 'credit' ? '+' : ''}{t.amount.toLocaleString()}
                    </span>
                  </td>
                  <td><span style={{ fontSize: 11, fontWeight: 600, color: t.status === 'completed' ? 'var(--emerald)' : 'var(--amber)' }}>{t.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
