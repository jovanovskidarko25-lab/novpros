import { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import StatCard from '../../components/ui/StatCard.jsx';
import Modal from '../../components/ui/Modal.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { CRM_LEADS, avatarColor } from '../../utils/data.js';
import { Plus, Search, Filter } from 'lucide-react';

const TT = { contentStyle: { background: 'var(--bg-surface)', border: '1px solid var(--border-default)', borderRadius: 8, fontSize: 12 } };

const PIPELINE = [
  { stage: 'Discovery',    value: 24, color: 'var(--sky)' },
  { stage: 'Demo',         value: 18, color: 'var(--accent)' },
  { stage: 'Proposal',     value: 12, color: 'var(--violet)' },
  { stage: 'Negotiation',  value: 8,  color: 'var(--amber)' },
  { stage: 'Closed',       value: 5,  color: 'var(--emerald)' },
];

const STATUS_COLOR = { hot: 'var(--rose)', warm: 'var(--amber)', qualified: 'var(--emerald)', cold: 'var(--sky)' };

export default function CrmDashboard() {
  const { toast } = useToast();
  const [leads, setLeads] = useState(CRM_LEADS);
  const [search, setSearch] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [newLead, setNewLead] = useState({ name: '', company: '', email: '', value: '', status: 'qualified', stage: 'Discovery' });

  const filtered = leads.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.company.toLowerCase().includes(search.toLowerCase())
  );

  const addLead = () => {
    if (!newLead.name || !newLead.company) { toast('Name and company required', 'error'); return; }
    setLeads(prev => [{ id: `l${Date.now()}`, ...newLead, value: Number(newLead.value) || 0, last: new Date().toISOString().slice(0,10) }, ...prev]);
    setAddOpen(false);
    setNewLead({ name: '', company: '', email: '', value: '', status: 'qualified', stage: 'Discovery' });
    toast('Lead added successfully', 'success');
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">CRM Dashboard</h1>
          <p className="page-subtitle">Customer relationship & pipeline management</p>
        </div>
        <button className="qx-btn btn-primary btn-sm" onClick={() => setAddOpen(true)}>
          <Plus size={14} /> Add Lead
        </button>
      </div>

      <div className="stats-grid u-mb-20">
        <StatCard label="Total Leads"     value={leads.length}        icon="👥" color="accent" />
        <StatCard label="Pipeline Value"  value="$306K"  change="+18%" trend="up" trendPositive icon="💼" color="emerald" />
        <StatCard label="Win Rate"        value="34%"    change="+5%"  trend="up" trendPositive icon="🏆" color="violet" />
        <StatCard label="Avg Deal Size"   value="$51K"   change="+9%"  trend="up" trendPositive icon="📊" color="amber" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: 16, marginBottom: 20 }}>
        {/* Leads table */}
        <div className="qx-card">
          <div className="card-header">
            <div className="card-title">All Leads</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ position: 'relative' }}>
                <Search size={13} style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
                <input className="qx-input btn-sm" placeholder="Search leads…" value={search}
                  onChange={e => setSearch(e.target.value)} style={{ paddingLeft: 28, width: 160 }} />
              </div>
            </div>
          </div>
          <div className="u-overflow-x-auto">
            <table className="qx-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Company</th>
                  <th>Value</th>
                  <th>Stage</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(l => (
                  <tr key={l.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 28, height: 28, borderRadius: '50%', background: avatarColor(l.name), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: 'white', flexShrink: 0 }}>
                          {l.name.split(' ').map(p => p[0]).join('').slice(0,2)}
                        </div>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{l.name}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{l.email}</div>
                        </div>
                      </div>
                    </td>
                    <td>{l.company}</td>
                    <td style={{ fontWeight: 600, color: 'var(--text-primary)', fontFamily: 'var(--font-mono)' }}>${l.value.toLocaleString()}</td>
                    <td>{l.stage}</td>
                    <td>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 99, background: `${STATUS_COLOR[l.status]}18`, color: STATUS_COLOR[l.status], border: `1px solid ${STATUS_COLOR[l.status]}33` }}>
                        <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />
                        {l.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pipeline chart */}
        <div className="qx-card">
          <div className="card-header">
            <div><div className="card-title">Pipeline by Stage</div></div>
          </div>
          <div className="card-body">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={PIPELINE} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} />
                <YAxis type="category" dataKey="stage" tick={{ fontSize: 11, fill: 'var(--text-tertiary)' }} width={80} />
                <Tooltip {...TT} />
                <Bar dataKey="value" radius={[0,4,4,0]}>
                  {PIPELINE.map((e, i) => (
                    <rect key={i} fill={e.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Add Lead Modal */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add New Lead" subtitle="Fill in the lead details below"
        footer={<>
          <button className="qx-btn btn-secondary" onClick={() => setAddOpen(false)}>Cancel</button>
          <button className="qx-btn btn-primary" onClick={addLead}>Add Lead</button>
        </>}
      >
        {[['name','Full Name','text','text'],['company','Company','text','organization'],['email','Email','email','email'],['value','Deal Value ($)','number','']].map(([k,l,t,ac]) => (
          <div key={k} className="qx-field">
            <label className="qx-label">{l}</label>
            <input className="qx-input" type={t} autoComplete={ac} value={newLead[k]} onChange={e => setNewLead(p => ({...p,[k]:e.target.value}))} />
          </div>
        ))}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="qx-field">
            <label className="qx-label">Status</label>
            <select className="qx-select" value={newLead.status} onChange={e => setNewLead(p => ({...p,status:e.target.value}))}>
              {['hot','warm','qualified','cold'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="qx-field">
            <label className="qx-label">Stage</label>
            <select className="qx-select" value={newLead.stage} onChange={e => setNewLead(p => ({...p,stage:e.target.value}))}>
              {['Discovery','Demo','Proposal','Negotiation','Closed'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </Modal>
    </div>
  );
}
