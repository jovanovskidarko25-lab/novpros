import { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { Camera, Shield } from 'lucide-react';

const TABS = ['Profile', 'Security', 'Activity'];

const ACTIVITY_LOG = [
  { action: 'Logged in from Chrome / macOS',       time: '2 min ago',  icon: '🔑' },
  { action: 'Updated billing plan to Pro',          time: '2h ago',     icon: '💳' },
  { action: 'Downloaded invoice INV-0849',          time: '4h ago',     icon: '📄' },
  { action: 'Added lead: Sarah Chen / Vertex Corp', time: 'Yesterday',  icon: '👤' },
  { action: 'Changed password',                     time: '3 days ago', icon: '🔒' },
  { action: 'Enabled 2-factor authentication',      time: '5 days ago', icon: '🛡️' },
];

export default function ProfilePage() {
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [tab, setTab]   = useState('Profile');
  const [form, setForm] = useState({
    name: user.name, email: user.email, phone: user.phone,
    location: user.location, bio: user.bio, website: user.website,
  });
  const [pw, setPw]           = useState({ current: '', next: '', confirm: '' });
  const [pwErrors, setPwErrors] = useState({});
  const [twoFactor, setTwoFactor] = useState(user.twoFactorEnabled);
  const fileRef = useRef();

  const saveProfile = () => {
    if (!form.name.trim()) { toast('Name required', 'error'); return; }
    updateUser(form);
    toast('Profile updated!', 'success');
  };

  const changePw = () => {
    const e = {};
    if (!pw.current)            e.current = 'Required';
    if (pw.next.length < 8)     e.next    = 'Min 8 characters';
    if (pw.next !== pw.confirm) e.confirm = "Passwords don't match";
    setPwErrors(e);
    if (!Object.keys(e).length) {
      toast('Password changed!', 'success');
      setPw({ current: '', next: '', confirm: '' });
    }
  };

  const handleAvatar = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    updateUser({ avatar: URL.createObjectURL(file) });
    toast('Avatar updated!', 'success');
  };

  return (
    <div className="page-container u-max-w-800">
      <div className="page-header">
        <div>
          <h1 className="page-title">Profile</h1>
          <p className="page-subtitle">Manage your personal information and security</p>
        </div>
      </div>

      {/* Avatar hero card */}
      <div className="qx-card u-mb-20">
        <div className="profile-hero">
          <div className="u-relative">
            <div className="u-avatar-circle u-avatar-80">
              {user.avatar
                ? <img src={user.avatar} alt="avatar" className="profile-avatar-img" />
                : user.initials}
            </div>
            <button
              onClick={() => fileRef.current.click()}
              aria-label="Upload avatar"
              className="u-avatar-upload-btn"
            >
              <Camera size={12} color="white" />
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="u-hidden" onChange={handleAvatar} />
          </div>

          <div className="profile-hero-info">
            <div className="profile-hero-name">{user.name}</div>
            <div className="profile-hero-role">{user.role} · {user.company}</div>
            <div className="profile-hero-joined">Member since {user.joined}</div>
          </div>

          <div className="u-ml-auto">
            <span className="u-plan-badge">{user.plan} Plan</span>
          </div>
        </div>
      </div>

      {/* Tab row */}
      <div className="u-tab-row">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`u-tab-btn ${tab === t ? 'u-tab-btn--active' : 'u-tab-btn--inactive'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Profile tab */}
      {tab === 'Profile' && (
        <div className="qx-card">
          <div className="card-header"><div className="card-title">Personal Information</div></div>
          <div className="card-body">
            <div className="profile-fields-grid">
              {[
                ['name',     'Full Name',       'text'],
                ['email',    'Email Address',   'email'],
                ['phone',    'Phone',           'tel'],
                ['location', 'Location',        'text'],
                ['website',  'Website',         'url'],
              ].map(([k, l, t]) => (
                <div key={k} className={`qx-field${k === 'website' ? ' profile-field--full' : ''}`}>
                  <label className="qx-label">{l}</label>
                  <input
                    className="qx-input" type={t}
                    value={form[k] || ''}
                    onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))}
                  />
                </div>
              ))}
              <div className="qx-field profile-field--full">
                <label className="qx-label">Bio</label>
                <textarea
                  className="qx-textarea u-resize-v"
                  rows={3}
                  value={form.bio || ''}
                  onChange={e => setForm(p => ({ ...p, bio: e.target.value }))}
                />
              </div>
            </div>
            <div className="u-flex-end u-mt-8">
              <button className="qx-btn btn-primary" onClick={saveProfile}>Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {/* Security tab */}
      {tab === 'Security' && (
        <div className="u-flex-col u-gap-16">
          <div className="qx-card">
            <div className="card-header"><div className="card-title">Change Password</div></div>
            <div className="card-body">
              {[['current','Current Password'],['next','New Password'],['confirm','Confirm New Password']].map(([k, l]) => (
                <div key={k} className="qx-field">
                  <label className="qx-label">{l}</label>
                  <input
                    className={`qx-input${pwErrors[k] ? ' error' : ''}`}
                    type="password" value={pw[k]}
                    onChange={e => setPw(p => ({ ...p, [k]: e.target.value }))}
                  />
                  {pwErrors[k] && <p className="field-error">{pwErrors[k]}</p>}
                </div>
              ))}
              <button className="qx-btn btn-primary btn-sm" onClick={changePw}>Update Password</button>
            </div>
          </div>

          <div className="qx-card">
            <div className="card-header"><div className="card-title">Two-Factor Authentication</div></div>
            <div className="card-body">
              <div className="profile-2fa-row">
                <Shield
                  size={32}
                  className={twoFactor ? 'profile-2fa-icon--on' : 'profile-2fa-icon--off'}
                />
                <div>
                  <div className="profile-2fa-label">
                    {twoFactor ? '2FA is enabled' : '2FA is disabled'}
                  </div>
                  <div className="profile-2fa-desc">
                    {twoFactor
                      ? 'Your account is protected with two-factor authentication.'
                      : 'Add an extra layer of security to your account.'}
                  </div>
                </div>
              </div>
              <button
                className={`qx-btn btn-sm ${twoFactor ? 'btn-danger' : 'btn-primary'}`}
                onClick={() => {
                  setTwoFactor(v => !v);
                  toast(twoFactor ? '2FA disabled' : '2FA enabled!', twoFactor ? 'warning' : 'success');
                }}
              >
                {twoFactor ? 'Disable 2FA' : 'Enable 2FA'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Activity tab */}
      {tab === 'Activity' && (
        <div className="qx-card">
          <div className="card-header"><div className="card-title">Recent Activity</div></div>
          {ACTIVITY_LOG.map((a, i) => (
            <div key={i} className={`activity-row${i === ACTIVITY_LOG.length - 1 ? ' activity-row--last' : ''}`}>
              <span className="activity-icon">{a.icon}</span>
              <div className="activity-text">{a.action}</div>
              <span className="activity-time">{a.time}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
