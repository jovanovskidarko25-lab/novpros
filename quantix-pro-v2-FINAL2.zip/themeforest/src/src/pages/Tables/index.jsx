import { useState } from 'react';
import { useToast } from '../../context/ToastContext.jsx';
import { TABLE_ROWS, exportCSV } from '../../utils/data.js';
import { Search, Download, ChevronUp, ChevronDown } from 'lucide-react';
import { useDebounce as useDB } from '../../hooks/index.js';

const STATUS_COLOR = { active: 'var(--emerald)', inactive: 'var(--rose)', pending: 'var(--amber)' };
const PER_PAGE = 8;

export default function TablesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState('name');
  const [sortDir, setSortDir] = useState('asc');
  const [page, setPage] = useState(1);
  const [roleFilter, setRoleFilter] = useState('all');
  const dSearch = useDB(search, 250);

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
    setPage(1);
  };

  const filtered = TABLE_ROWS
    .filter(r => {
      const q = dSearch.toLowerCase();
      return (r.name.toLowerCase().includes(q) || r.email.toLowerCase().includes(q) || r.role.toLowerCase().includes(q))
        && (roleFilter === 'all' || r.role === roleFilter);
    })
    .sort((a, b) => {
      const va = a[sortKey], vb = b[sortKey];
      if (typeof va === 'number') return sortDir === 'asc' ? va - vb : vb - va;
      return sortDir === 'asc' ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    });

  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const visible = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const SortIcon = ({ k }) => sortKey === k
    ? (sortDir === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)
    : <span style={{ opacity: 0.3 }}><ChevronUp size={12} /></span>;

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">Data Tables</h1><p className="page-subtitle">Sortable, filterable user table with pagination</p></div>
        <button className="qx-btn btn-secondary btn-sm" onClick={() => {
          exportCSV('users.csv', ['Name','Email','Role','Status','Joined','Revenue'], filtered.map(r => [r.name,r.email,r.role,r.status,r.joined,r.revenue]));
          toast('Exported CSV!');
        }}>
          <Download size={13} /> Export CSV
        </button>
      </div>

      <div className="qx-card">
        {/* Toolbar */}
        <div className="card-header" style={{ gap: 12, flexWrap: 'wrap' }}>
          <div style={{ position: 'relative' }}>
            <Search size={13} style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
            <input className="qx-input" placeholder="Search users…" value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              style={{ paddingLeft: 28, width: 200 }} />
          </div>
          <select className="qx-select" style={{ width: 140 }} value={roleFilter} onChange={e => { setRoleFilter(e.target.value); setPage(1); }}>
            <option value="all">All roles</option>
            {['Admin','Developer','Designer','Manager','Analyst'].map(r => <option key={r}>{r}</option>)}
          </select>
          <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text-tertiary)' }}>{filtered.length} users</span>
        </div>

        {/* Table */}
        <div className="u-overflow-x-auto">
          <table className="qx-table">
            <thead>
              <tr>
                {[['name','Name'],['email','Email'],['role','Role'],['status','Status'],['joined','Joined'],['revenue','Revenue']].map(([k,l]) => (
                  <th key={k} className="sortable" onClick={() => toggleSort(k)} style={{ cursor: 'pointer' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>{l} <SortIcon k={k} /></span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: 40, color: 'var(--text-tertiary)' }}>No results found</td></tr>
              ) : visible.map(r => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{r.name}</td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>{r.email}</td>
                  <td><span style={{ fontSize: 11, background: 'var(--bg-overlay)', padding: '2px 7px', borderRadius: 4, border: '1px solid var(--border-subtle)' }}>{r.role}</span></td>
                  <td>
                    <span style={{ fontSize: 11, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 99, background: `${STATUS_COLOR[r.status]}15`, color: STATUS_COLOR[r.status] }}>
                      <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />{r.status}
                    </span>
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>{r.joined}</td>
                  <td style={{ fontWeight: 600, fontFamily: 'var(--font-mono)' }}>${r.revenue.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', borderTop: '1px solid var(--border-subtle)', flexWrap: 'wrap', gap: 8 }}>
          <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
            Showing {Math.min((page-1)*PER_PAGE+1, filtered.length)}–{Math.min(page*PER_PAGE, filtered.length)} of {filtered.length}
          </span>
          <div style={{ display: 'flex', gap: 4 }}>
            <button className="qx-btn btn-secondary btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
            {Array.from({ length: pages }, (_, i) => i + 1).map(p => (
              <button key={p} className="qx-btn btn-sm" onClick={() => setPage(p)}
                style={{ background: p === page ? 'var(--accent)' : 'var(--bg-elevated)', color: p === page ? 'white' : 'var(--text-secondary)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)' }}>
                {p}
              </button>
            ))}
            <button className="qx-btn btn-secondary btn-sm" disabled={page === pages} onClick={() => setPage(p => p + 1)}>Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
