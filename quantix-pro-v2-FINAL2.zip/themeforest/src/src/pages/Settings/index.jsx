import { useState } from 'react';
import { useTheme } from '../../context/ThemeContext.jsx';
import { useToast } from '../../context/ToastContext.jsx';
import { Sun, Moon, Languages, Bell, Palette, Database, Shield, Globe } from 'lucide-react';

function Section({ icon: Icon, title, children }) {
  return (
    <div className="qx-card" style={{ marginBottom: 16 }}>
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Icon size={15} style={{ color: 'var(--accent)' }} />
          <div className="card-title">{title}</div>
        </div>
      </div>
      <div className="card-body">{children}</div>
    </div>
  );
}

function ToggleRow({ label, desc, value, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border-subtle)' }}>
      <div>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{label}</div>
        {desc && <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 1 }}>{desc}</div>}
      </div>
      <button
        role="switch" aria-checked={value} onClick={() => onChange(!value)}
        style={{ width: 42, height: 24, borderRadius: 12, background: value ? 'var(--accent)' : 'var(--bg-overlay)', border: 'none', cursor: 'pointer', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}
      >
        <span style={{ position: 'absolute', top: 3, left: value ? 20 : 3, width: 18, height: 18, borderRadius: '50%', background: 'white', transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
      </button>
    </div>
  );
}

export default function SettingsPage() {
  const { theme, toggleTheme, dir, toggleDir } = useTheme();
  const { toast } = useToast();

  const [notifs, setNotifs] = useState({ email: true, push: false, digest: true, security: true, marketing: false });
  const [privacy, setPrivacy] = useState({ analytics: true, crash: true, personalization: false });
  const [accent, setAccent] = useState('#6366f1');

  const ACCENTS = [
    { color: '#6366f1', label: 'Indigo' },
    { color: '#8b5cf6', label: 'Violet' },
    { color: '#06b6d4', label: 'Cyan' },
    { color: '#10b981', label: 'Emerald' },
    { color: '#f59e0b', label: 'Amber' },
    { color: '#f43f5e', label: 'Rose' },
  ];

  return (
    <div className="page-container" style={{ maxWidth: 720 }}>
      <div className="page-header"><div><h1 className="page-title">Settings</h1><p className="page-subtitle">Customize your Quantix Pro experience</p></div></div>

      <Section icon={Palette} title="Appearance">
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          {[['dark','Dark','🌙'],['light','Light','☀️']].map(([v,l,e]) => (
            <button key={v} onClick={() => { if (theme !== v) toggleTheme(); }}
              style={{ flex: 1, minWidth: 120, padding: '16px', borderRadius: 'var(--radius-lg)', border: theme === v ? '2px solid var(--accent)' : '1px solid var(--border-default)', background: theme === v ? 'var(--accent-bg)' : 'var(--bg-elevated)', cursor: 'pointer', textAlign: 'center', transition: 'all 0.15s' }}>
              <div style={{ fontSize: 24, marginBottom: 6 }}>{e}</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: theme === v ? 'var(--accent)' : 'var(--text-secondary)' }}>{l} Mode</div>
            </button>
          ))}
        </div>
        <div style={{ marginBottom: 16 }}>
          <div className="qx-label" style={{ marginBottom: 10 }}>Accent Color</div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {ACCENTS.map(a => (
              <button key={a.color} onClick={() => { setAccent(a.color); document.documentElement.style.setProperty('--accent', a.color); toast(`Accent: ${a.label}`, 'success'); }}
                aria-label={`${a.label} accent`}
                style={{ width: 36, height: 36, borderRadius: '50%', background: a.color, border: accent === a.color ? '3px solid var(--text-primary)' : '3px solid transparent', cursor: 'pointer', transition: 'border 0.15s' }} />
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0' }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>Text Direction (RTL)</div>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>Switch to right-to-left layout (Arabic, Hebrew)</div>
          </div>
          <button className="qx-btn btn-secondary btn-sm" onClick={toggleDir}>{dir === 'rtl' ? '← Switch to LTR' : 'Switch to RTL →'}</button>
        </div>
      </Section>

      <Section icon={Bell} title="Notifications">
        {[
          ['email',   'Email notifications',    'Receive updates via email'],
          ['push',    'Push notifications',      'Browser push alerts'],
          ['digest',  'Weekly digest',           'Summary of activity every Monday'],
          ['security','Security alerts',         'Login and account security events'],
          ['marketing','Marketing emails',       'Product updates and announcements'],
        ].map(([k,l,d]) => (
          <ToggleRow key={k} label={l} desc={d} value={notifs[k]} onChange={v => { setNotifs(p=>({...p,[k]:v})); toast(`${l} ${v?'enabled':'disabled'}`, 'success'); }} />
        ))}
      </Section>

      <Section icon={Shield} title="Privacy & Data">
        {[
          ['analytics',       'Usage analytics',        'Help improve Quantix by sharing usage data'],
          ['crash',           'Crash reports',           'Automatically send crash logs'],
          ['personalization', 'Personalization',         'Use your data to personalise your experience'],
        ].map(([k,l,d]) => (
          <ToggleRow key={k} label={l} desc={d} value={privacy[k]} onChange={v => setPrivacy(p=>({...p,[k]:v}))} />
        ))}
      </Section>

      <Section icon={Database} title="Data Management">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button className="qx-btn btn-secondary btn-sm" style={{ width: 'fit-content' }} onClick={() => toast('Export started — check your email', 'info')}>
            Export all my data
          </button>
          <button className="qx-btn btn-danger btn-sm" style={{ width: 'fit-content' }} onClick={() => toast('Request received. Deletion in 30 days.', 'warning')}>
            Delete account
          </button>
        </div>
      </Section>
    </div>
  );
}
