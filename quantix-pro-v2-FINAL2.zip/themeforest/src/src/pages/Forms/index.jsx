import { useState } from 'react';
import { useToast } from '../../context/ToastContext.jsx';
import { isValidEmail } from '../../utils/data.js';
import { CheckCircle } from 'lucide-react';

function Field({ label, error, children }) {
  return (
    <div className="qx-field">
      {label && <label className="qx-label">{label}</label>}
      {children}
      {error && <p className="field-error" role="alert">{error}</p>}
    </div>
  );
}

export default function FormsPage() {
  const { toast } = useToast();
  const [contact, setContact] = useState({ name:'', email:'', subject:'', message:'', priority:'medium' });
  const [contactErrors, setContactErrors] = useState({});
  const [contactDone, setContactDone] = useState(false);

  const [account, setAccount] = useState({ username:'', bio:'', website:'', language:'en', notifications:{ email:true, push:false, sms:false } });

  const [payment, setPayment] = useState({ card:'', expiry:'', cvv:'', name:'' });
  const [paymentErrors, setPaymentErrors] = useState({});

  const validateContact = () => {
    const e = {};
    if (!contact.name.trim())             e.name    = 'Full name is required';
    if (!isValidEmail(contact.email))     e.email   = 'Valid email required';
    if (!contact.subject.trim())          e.subject = 'Subject is required';
    if (contact.message.length < 10)      e.message = 'Message must be at least 10 characters';
    return e;
  };

  const submitContact = () => {
    const e = validateContact();
    setContactErrors(e);
    if (Object.keys(e).length === 0) {
      setContactDone(true);
      toast('Message sent!', 'success');
    }
  };

  const validatePayment = () => {
    const e = {};
    if (!payment.name.trim())            e.name   = 'Name on card required';
    if (!/^\d{13,19}$/.test(payment.card.replace(/\s/g,''))) e.card = 'Valid card number required';
    if (!/^\d{2}\/\d{2}$/.test(payment.expiry)) e.expiry = 'Format: MM/YY';
    if (!/^\d{3,4}$/.test(payment.cvv)) e.cvv  = '3–4 digits';
    return e;
  };

  const formatCard = (v) => v.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim();
  const formatExpiry = (v) => { const d = v.replace(/\D/g,'').slice(0,4); return d.length > 2 ? `${d.slice(0,2)}/${d.slice(2)}` : d; };

  return (
    <div className="page-container">
      <div className="page-header"><div><h1 className="page-title">Forms</h1><p className="page-subtitle">Validated form components and patterns</p></div></div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 20 }}>
        {/* Contact form */}
        <div className="qx-card">
          <div className="card-header"><div><div className="card-title">Contact Form</div><div className="card-subtitle">With validation</div></div></div>
          <div className="card-body">
            {contactDone ? (
              <div style={{ textAlign: 'center', padding: '24px 0' }}>
                <CheckCircle size={40} style={{ color: 'var(--emerald)', marginBottom: 12 }} />
                <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 6 }}>Message sent!</div>
                <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 16 }}>We'll get back to you within 24 hours.</div>
                <button className="qx-btn btn-secondary btn-sm" onClick={() => { setContactDone(false); setContact({ name:'', email:'', subject:'', message:'', priority:'medium' }); }}>Send another</button>
              </div>
            ) : (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <Field label="Full Name" error={contactErrors.name}>
                    <input className={`qx-input${contactErrors.name?' error':''}`} value={contact.name} onChange={e => setContact(p=>({...p,name:e.target.value}))} placeholder="Alex Morgan" />
                  </Field>
                  <Field label="Email" error={contactErrors.email}>
                    <input className={`qx-input${contactErrors.email?' error':''}`} type="email" value={contact.email} onChange={e => setContact(p=>({...p,email:e.target.value}))} placeholder="you@example.com" />
                  </Field>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12 }}>
                  <Field label="Subject" error={contactErrors.subject}>
                    <input className={`qx-input${contactErrors.subject?' error':''}`} value={contact.subject} onChange={e => setContact(p=>({...p,subject:e.target.value}))} placeholder="How can we help?" />
                  </Field>
                  <Field label="Priority">
                    <select className="qx-select" value={contact.priority} onChange={e => setContact(p=>({...p,priority:e.target.value}))}>
                      {['low','medium','high','urgent'].map(o=><option key={o}>{o}</option>)}
                    </select>
                  </Field>
                </div>
                <Field label="Message" error={contactErrors.message}>
                  <textarea className={`qx-textarea${contactErrors.message?' error':''}`} rows={4} value={contact.message} onChange={e => setContact(p=>({...p,message:e.target.value}))} placeholder="Describe your request in detail…" style={{ resize: 'vertical' }} />
                  <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 3, textAlign: 'right' }}>{contact.message.length} chars</div>
                </Field>
                <button className="qx-btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={submitContact}>Send Message →</button>
              </>
            )}
          </div>
        </div>

        {/* Account settings form */}
        <div className="qx-card">
          <div className="card-header"><div><div className="card-title">Account Settings</div><div className="card-subtitle">Profile & preferences</div></div></div>
          <div className="card-body">
            <Field label="Username">
              <div style={{ display: 'flex' }}>
                <span style={{ display: 'flex', alignItems: 'center', padding: '0 10px', background: 'var(--bg-overlay)', border: '1px solid var(--border-default)', borderRight: 'none', borderRadius: 'var(--radius-md) 0 0 var(--radius-md)', fontSize: 13, color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>@</span>
                <input className="qx-input" value={account.username} onChange={e => setAccount(p=>({...p,username:e.target.value}))} style={{ borderRadius: '0 var(--radius-md) var(--radius-md) 0' }} placeholder="your_handle" />
              </div>
            </Field>
            <Field label="Bio">
              <textarea className="qx-textarea" rows={3} value={account.bio} onChange={e => setAccount(p=>({...p,bio:e.target.value}))} placeholder="Tell us a bit about yourself…" style={{ resize: 'none' }} />
            </Field>
            <Field label="Website">
              <input className="qx-input" value={account.website} onChange={e => setAccount(p=>({...p,website:e.target.value}))} placeholder="https://yoursite.com" type="url" />
            </Field>
            <Field label="Language">
              <select className="qx-select" value={account.language} onChange={e => setAccount(p=>({...p,language:e.target.value}))}>
                <option value="en">English</option>
                <option value="fr">Français</option>
                <option value="de">Deutsch</option>
                <option value="es">Español</option>
                <option value="ar">العربية</option>
              </select>
            </Field>
            <div style={{ marginBottom: 14 }}>
              <div className="qx-label" style={{ marginBottom: 10 }}>Notifications</div>
              {[['email','Email notifications'],['push','Push notifications'],['sms','SMS alerts']].map(([k,l]) => (
                <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, cursor: 'pointer' }}>
                  <input type="checkbox" checked={account.notifications[k]}
                    onChange={e => setAccount(p=>({...p,notifications:{...p.notifications,[k]:e.target.checked}}))}
                    style={{ accentColor: 'var(--accent)', width: 16, height: 16 }} />
                  <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{l}</span>
                </label>
              ))}
            </div>
            <button className="qx-btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={() => toast('Settings saved!', 'success')}>Save Settings</button>
          </div>
        </div>

        {/* Payment form */}
        <div className="qx-card">
          <div className="card-header"><div><div className="card-title">Payment Form</div><div className="card-subtitle">Formatted card input</div></div></div>
          <div className="card-body">
            <div style={{ background: 'linear-gradient(135deg, var(--accent), var(--violet))', borderRadius: 'var(--radius-lg)', padding: '20px 20px 16px', marginBottom: 20, position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: -20, right: -20, width: 100, height: 100, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', marginBottom: 14, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Credit Card</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 700, color: 'white', letterSpacing: '0.2em', marginBottom: 16 }}>
                {payment.card || '•••• •••• •••• ••••'}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div><div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>Card Holder</div><div style={{ fontSize: 13, color: 'white', fontWeight: 600 }}>{payment.name || 'Your Name'}</div></div>
                <div><div style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>Expiry</div><div style={{ fontSize: 13, color: 'white', fontWeight: 600, fontFamily: 'var(--font-mono)' }}>{payment.expiry || 'MM/YY'}</div></div>
              </div>
            </div>
            <Field label="Name on Card" error={paymentErrors.name}>
              <input className={`qx-input${paymentErrors.name?' error':''}`} value={payment.name} onChange={e => setPayment(p=>({...p,name:e.target.value}))} placeholder="Alex Morgan" autoComplete="cc-name" />
            </Field>
            <Field label="Card Number" error={paymentErrors.card}>
              <input className={`qx-input${paymentErrors.card?' error':''}`} value={payment.card} onChange={e => setPayment(p=>({...p,card:formatCard(e.target.value)}))} placeholder="1234 5678 9012 3456" autoComplete="cc-number" inputMode="numeric" maxLength={19} style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }} />
            </Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <Field label="Expiry" error={paymentErrors.expiry}>
                <input className={`qx-input${paymentErrors.expiry?' error':''}`} value={payment.expiry} onChange={e => setPayment(p=>({...p,expiry:formatExpiry(e.target.value)}))} placeholder="MM/YY" autoComplete="cc-exp" maxLength={5} style={{ fontFamily: 'var(--font-mono)' }} />
              </Field>
              <Field label="CVV" error={paymentErrors.cvv}>
                <input className={`qx-input${paymentErrors.cvv?' error':''}`} type="password" value={payment.cvv} onChange={e => setPayment(p=>({...p,cvv:e.target.value.replace(/\D/,'').slice(0,4)}))} placeholder="•••" autoComplete="cc-csc" maxLength={4} style={{ fontFamily: 'var(--font-mono)' }} />
              </Field>
            </div>
            <button className="qx-btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}
              onClick={() => { const e = validatePayment(); setPaymentErrors(e); if (!Object.keys(e).length) toast('Payment processed!', 'success'); }}>
              Pay Now →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
