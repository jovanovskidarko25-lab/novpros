import { useState } from 'react';
import { useToast } from '../../context/ToastContext.jsx';
import { KANBAN_COLUMNS, avatarColor, randomId } from '../../utils/data.js';
import { Plus, GripVertical } from 'lucide-react';

const PRIORITY_COLOR = { critical:'var(--rose)', high:'var(--orange)', medium:'var(--amber)', low:'var(--sky)' };

export default function KanbanPage() {
  const { toast } = useToast();
  const [cols, setCols] = useState(KANBAN_COLUMNS);
  const [drag, setDrag] = useState(null);
  const [addingCol, setAddingCol] = useState(null);
  const [newCard, setNewCard] = useState('');

  const onDragStart = (cardId, fromCol) => setDrag({ cardId, fromCol });
  const onDrop = (toColId) => {
    if (!drag || drag.fromCol === toColId) { setDrag(null); return; }
    setCols(prev => {
      const card = prev.find(c => c.id === drag.fromCol).cards.find(c => c.id === drag.cardId);
      return prev.map(col => {
        if (col.id === drag.fromCol) return { ...col, cards: col.cards.filter(c => c.id !== drag.cardId) };
        if (col.id === toColId)      return { ...col, cards: [...col.cards, card] };
        return col;
      });
    });
    toast('Card moved', 'success');
    setDrag(null);
  };

  const addCard = (colId) => {
    if (!newCard.trim()) return;
    setCols(prev => prev.map(col => col.id !== colId ? col : {
      ...col, cards: [...col.cards, { id: randomId(), title: newCard, priority: 'medium', assignee: 'AM', due: '' }]
    }));
    setNewCard(''); setAddingCol(null); toast('Card added', 'success');
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div><h1 className="page-title">Kanban Board</h1><p className="page-subtitle">Drag cards between columns to update status</p></div>
      </div>
      <div style={{ display: 'flex', gap: 16, overflowX: 'auto', paddingBottom: 16 }}>
        {cols.map(col => (
          <div
            key={col.id}
            style={{ minWidth: 260, maxWidth: 300, flex: '0 0 260px' }}
            onDragOver={e => e.preventDefault()}
            onDrop={() => onDrop(col.id)}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: col.color }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{col.title}</span>
              <span style={{ marginLeft: 'auto', fontSize: 11, background: 'var(--bg-elevated)', padding: '2px 7px', borderRadius: 99, color: 'var(--text-secondary)', border: '1px solid var(--border-subtle)' }}>{col.cards.length}</span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minHeight: 100 }}>
              {col.cards.map(card => (
                <div
                  key={card.id}
                  draggable
                  onDragStart={() => onDragStart(card.id, col.id)}
                  className="qx-card"
                  style={{ cursor: 'grab', opacity: drag?.cardId === card.id ? 0.5 : 1 }}
                >
                  <div style={{ padding: '12px 14px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, gap: 8 }}>
                      <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)', lineHeight: 1.4 }}>{card.title}</div>
                      <GripVertical size={14} style={{ color: 'var(--text-muted)', flexShrink: 0, marginTop: 2 }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 11, fontWeight: 600, padding: '1px 6px', borderRadius: 99, background: `${PRIORITY_COLOR[card.priority]}18`, color: PRIORITY_COLOR[card.priority] }}>{card.priority}</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        {card.due && <span style={{ fontSize: 10, color: 'var(--text-tertiary)' }}>{card.due}</span>}
                        <div style={{ width: 22, height: 22, borderRadius: '50%', background: avatarColor(card.assignee), display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700, color: 'white' }}>{card.assignee}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {addingCol === col.id ? (
                <div className="qx-card" style={{ padding: 12 }}>
                  <textarea
                    autoFocus
                    className="qx-textarea"
                    style={{ resize: 'none', fontSize: 13, marginBottom: 8 }}
                    rows={2}
                    placeholder="Card title…"
                    value={newCard}
                    onChange={e => setNewCard(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addCard(col.id); } if (e.key === 'Escape') { setAddingCol(null); setNewCard(''); } }}
                  />
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="qx-btn btn-primary btn-sm" onClick={() => addCard(col.id)}>Add</button>
                    <button className="qx-btn btn-secondary btn-sm" onClick={() => { setAddingCol(null); setNewCard(''); }}>Cancel</button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setAddingCol(col.id)}
                  style={{ display: 'flex', alignItems: 'center', gap: 6, width: '100%', padding: '8px 12px', background: 'transparent', border: '1px dashed var(--border-default)', borderRadius: 'var(--radius-md)', fontSize: 12, color: 'var(--text-tertiary)', cursor: 'pointer', fontFamily: 'var(--font-sans)', transition: 'all 0.15s' }}
                >
                  <Plus size={12} /> Add card
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
