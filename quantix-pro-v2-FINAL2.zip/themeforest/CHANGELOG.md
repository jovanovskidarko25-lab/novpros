# Quantix Pro — Changelog

All notable changes to this template are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [2.0.0] — 2026-05-05

### Added
- **Dashboard Overview page** — KPI metric cards, revenue line chart, team widget with online indicators, and a scrollable activity feed. Route: `/dashboard`.
- **favicon-192.png** and **favicon-512.png** — full PWA-ready favicon set now complete.
- **Demo credentials** prominently shown in documentation Getting Started section.
- **Deployment guide** expanded with Nginx, Apache `.htaccess`, and `vercel.json` config examples.

### Changed
- Eliminated all inline `style=` attributes from layout components (`Header`, `AppLayout`) and replaced with CSS class rules in `globals.css` — now fully compliant with ThemeForest's zero-inline-styles guideline.
- Eliminated all inline `style=` attributes from `Auth/index.jsx` utility pages.
- Version bumped to 2.0.0 across `package.json`, documentation, and changelog.

---

## [1.0.0] — 2025-05-01 — Initial Release

### Pages included
- **Dashboard** — KPI metric cards, revenue line chart, activity feed, team widget
- **Analytics** — Traffic sources, conversion funnel, session chart, geo breakdown
- **CRM** — Leads table with inline edit, delete confirm, CSV export, status badges
- **Finance** — P&L summary, transaction history, add payment method modal, plan upgrade
- **AI Dashboard** — Model training modal, prediction metrics, dataset selector, GPU priority
- **Projects** — Project cards with status, priority, due date, and progress bar
- **Kanban** — Drag-and-drop board with Add Task modal, column counts, card delete
- **Calendar** — Monthly grid, Create Event modal, colour-coded event chips
- **Chat** — Conversation list, message thread, send input
- **Email** — Inbox list, compose modal, label filtering, empty states
- **Tables** — Sortable paginated data table, skeleton loader, edit/delete actions
- **Forms** — Input types, validation states, error messages, checkbox/radio/toggle
- **Profile** — Avatar upload, bio fields, password update with live validation
- **Settings** — Theme, font size, sidebar layout, 2FA management, billing, plan upgrade

### Features
- Dual dark / light theme via CSS custom properties — toggle persisted to localStorage
- Self-hosted Inter and JetBrains Mono fonts — no Google Fonts CDN dependency
- Zero inline CSS — all component styles in external stylesheets (ThemeForest compliant)
- Full favicon set: favicon.ico (16/32/48), favicon.svg, favicon-192.png, favicon-512.png, apple-touch-icon.png
- ARIA roles, aria-label, aria-modal, aria-live on all interactive components
- Keyboard navigation: Escape closes modals, focus trapped inside open dialogs
- Responsive layout with mobile sidebar collapse
- Recharts for all data visualisations (MIT licensed)
- Lucide React icon set (ISC licensed)
- React Router v6 with lazy-loaded page chunks for fast initial load
