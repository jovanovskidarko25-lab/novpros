# Quantix Pro — Premium React Admin & Dashboard Template

**Version:** 2.0.0  
**Built with:** React 18 · Vite 5 · React Router v6 · Recharts · Lucide React

---

## What's Included

The download package contains three folders:

| Folder | Contents |
|--------|----------|
| `src/` | Full editable source code — React + Vite project |
| `dist/` | Pre-built production files — upload directly to any web host |
| `documentation/` | Complete HTML documentation — open `documentation/index.html` |

---

## Quick Start

**Option A — Use the pre-built files (no Node.js needed)**  
Upload the entire contents of `dist/` to your web host or CDN. Done.

**Option B — Edit the source**

```bash
cd src
npm install
npm run dev        # start dev server at http://localhost:5173
npm run build      # compile production bundle → dist/
```

**Demo login credentials**

| Field | Value |
|-------|-------|
| Email | `admin@quantix.io` |
| Password | `admin123` |

These are hardcoded in `src/utils/data.js`. Remove or replace them before going live.

---

## Pages Included

**Dashboards:** Overview · Analytics · CRM · Finance · AI/ML  
**Management:** Projects · Kanban · Calendar  
**Communication:** Chat · Email  
**Data:** Tables · Forms  
**Account:** Profile · Settings  
**Utility:** Login · Register · Forgot Password · 404 · 500 · Coming Soon · Maintenance

---

## Features

- ☀️ **Dual theme** — dark & light, persisted to localStorage
- 🌍 **RTL support** — full right-to-left layout toggle
- 📱 **Responsive** — mobile sidebar collapse, fluid grids
- ♿ **Accessible** — ARIA roles, keyboard nav, skip links, focus trapping
- 🔤 **Self-hosted fonts** — Inter & JetBrains Mono, no Google CDN dependency
- ⚡ **Lazy-loaded routes** — per-page JS chunks for fast initial load
- 📊 **Recharts** — all data visualisations (MIT licensed)
- 🎨 **CSS custom properties** — full design token system, easy to retheme

---

## Browser Support

Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

---

## Documentation

Open `documentation/index.html` in any browser for the full guide covering installation, folder structure, theming, routing, adding pages, deployment configs, and credits.

---

## Support

Purchased from ThemeForest? Use the **Comments** tab on the item page to ask questions.  
Please read the documentation before posting — most questions are answered there.

---

## License

This template is licensed under the ThemeForest Regular / Extended License.  
Third-party libraries are MIT or ISC licensed — see `documentation/index.html` → Credits & Licenses.
